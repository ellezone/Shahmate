"""
ShahMate Trading Bot 
Run script for starting the web application
"""

import os
import logging
from app import app, add_bot_output, create_static_files

# Setup logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

logger = logging.getLogger(__name__)

# Ensure static folder and files exist
create_static_files()

# Create empty log file if it doesn't exist
if not os.path.exists('bot_log.txt'):
    with open('bot_log.txt', 'w') as f:
        f.write('# ShahMate Trading Bot Log\n')

if __name__ == '__main__':
    logger.info("Starting ShahMate Trading Bot Web Simulation at %s", "current_time")
    logger.info("Server configured to run on http://0.0.0.0:5000 (Debug: False)")
    
    # Log startup message
    add_bot_output("ShahMate Trading Bot Web Simulation started")
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=False)
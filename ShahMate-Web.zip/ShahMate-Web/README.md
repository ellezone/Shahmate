# ShahMate Crypto Trading Bot Web Simulation

A web-based simulation of the ShahMate cryptocurrency trading bot, featuring RSI-based trading strategy with EMA verification, multi-tier position averaging, and the Decrement December gradual purchase algorithm.

## Features

- **Login/Registration System**: Secure authentication to manage your trading settings.
- **Live Trading Simulation**: Test the trading strategy with real-time market data.
- **Backtesting**: Evaluate the strategy's performance using historical data.
- **RSI-based Strategy**: Trading decisions based on the Relative Strength Index indicator.
- **EMA Crossover Verification**: Additional confirmation signal for entry points.
- **Decrement December Algorithm**: Gradual position building with tier-based averaging.
- **Trailing Stop Loss**: Maximize profits by tracking peak prices and RSI values.
- **Dashboard**: Monitor your trading activities and overall performance.
- **Trade History**: Track all trades with profit/loss reporting.
- **Coin Recommendations**: Get suggestions for trading pairs based on current market conditions.
- **Customizable Settings**: Fine-tune all aspects of the trading algorithm.

## Trading Strategy Details

### Core Components

1. **RSI Strategy**: Identifies entry points at oversold conditions and exit points at overbought levels.
2. **Decrement December Algorithm**: Scales into positions gradually when RSI is oversold, with larger positions as RSI drops lower.
3. **Multi-tier Position Averaging**: Manages multiple entry positions with corresponding exit strategies.
4. **EMA Verification**: Only enters trades when price is above the EMA for trend confirmation.
5. **Trailing Stop**: Activates at high RSI levels to maximize profits in trending markets.

### Entry Conditions

- RSI below the oversold level (default: 28)
- Price above EMA (default: 10-period EMA)
- New buy price outside proximity range of previous buys

### Exit Conditions

- RSI above overbought level (default: 68)
- Trailing stop triggered (price drops by set percentage from peak)
- Profit target reached

## Getting Started

### Prerequisites

- Python 3.7+
- Required Python packages (installed automatically):
  - Flask
  - SQLAlchemy
  - python-binance
  - pandas
  - numpy
  - plotly
  - python-dotenv

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/shahmate-web.git
   cd shahmate-web
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the application:
   ```
   python run.py
   ```

4. Open the application in your browser:
   ```
   http://localhost:5000
   ```

## How to Use

1. **Register/Login**: Create an account to get started.
2. **API Settings**: Add your Binance API key and secret (optional, read-only permissions are sufficient for simulation).
3. **Bot Settings**: Customize the trading strategy parameters.
4. **Live Trading**: Start a trading simulation with real-time market data.
5. **Backtest**: Test the strategy against historical data.
6. **Recommended Coins**: Find trading pairs that match your strategy criteria.

## Important Notes

- This is a simulation tool for educational purposes.
- The web version does not execute real trades by default.
- When API keys are provided, the application can fetch real-time market data.
- All trades are simulated and recorded in the local database.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- ShahMate Trading Bot Android application (original version)
- Binance API for market data
- Technical indicators and trading strategy based on established financial principles
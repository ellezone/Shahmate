from flask import Flask, render_template_string, render_template, request, redirect, url_for
from threading import Thread
import os
import time
import requests
import pytz
import datetime
import random
from datetime import datetime, timedelta
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
from binance.client import Client
from binance.enums import *
# Define Binance API constants explicitly to avoid import issues
SIDE_BUY = 'BUY'
SIDE_SELL = 'SELL'
ORDER_TYPE_MARKET = 'MARKET'
import logging
import websocket
import ssl

# Configure logging
logging.basicConfig(filename='bot_log.txt', level=logging.INFO, 
                   format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)

# Global variables
api_key = ""
api_secret = ""
client = None
intervals = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"]
usdt_pairs = []
running_live = False
running_backtest = False
# Separate log arrays for different contexts
live_output = []
backtest_output = []
recommend_output = []
general_output = []
MAX_OUTPUT = 50
ws_app = None
last_ws_message = None

# Trading variables
current_total_money = 15000  # Default starting amount for backtesting
reserve_money_usdc = 5000    # Reserve USDC
total_spent = 0
total_coins = 0
total_profit_accumulated = 0
buy_counter = 0
last_buy_price = None
base_amount = 0
avg_price = 0
trailing_active = False
trailing_peak_rsi = 0
trailing_peak_value = 0

# Strategy variables
rsi_length = 7
oversold_level = 28
overbought_level = 68
proximity_range_percent = 2.5
profit_range = 2.5
max_buy_steps = 15
interval = "1m"
ema_period = 10
trailing_start_rsi = 73
trailing_stop_enabled = True
rsi_threshold = 28
price_change_threshold = 1.0
volume_change_threshold = 0.5
volatility_threshold = 2.0
vars_password = "123qwe"  # Simple password for variables page

# Create the static directory and style.css file if they don't exist
def create_static_files():
    os.makedirs("static", exist_ok=True)
    
    style_css = """
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #2c3e50;
        color: #ecf0f1;
        text-align: center;
    }
    h2 {
        color: #e67e22;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        background-color: #34495e;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    select, input, button {
        padding: 10px;
        margin: 5px;
        border-radius: 5px;
        border: none;
        background-color: #2c3e50;
        color: #ecf0f1;
    }
    button {
        background-color: #e67e22;
        cursor: pointer;
        font-weight: bold;
    }
    button:hover {
        background-color: #d35400;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    table, th, td {
        border: 1px solid #2c3e50;
    }
    th, td {
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #2c3e50;
    }
    tr:nth-child(even) {
        background-color: #2c3e50;
    }
    .bot-output {
        height: 300px;
        overflow-y: auto;
        background-color: #2c3e50;
        border-radius: 5px;
        padding: 10px;
        text-align: left;
        font-family: monospace;
        margin-top: 20px;
    }
    .status {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        margin-right: 5px;
    }
    .running {
        background-color: #2ecc71;
    }
    .stopped {
        background-color: #e74c3c;
    }
    .grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
    }
    .card {
        background-color: #2c3e50;
        border-radius: 5px;
        padding: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .card h3 {
        margin-top: 0;
        color: #e67e22;
    }
    .navbar {
        background-color: #2c3e50;
        overflow: hidden;
        margin-bottom: 20px;
        border-radius: 5px;
    }
    .navbar a {
        float: left;
        display: block;
        color: #ecf0f1;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }
    .navbar a:hover {
        background-color: #e67e22;
    }
    .navbar a.active {
        background-color: #e67e22;
    }
    .footer {
        margin-top: 20px;
        padding: 10px;
        background-color: #2c3e50;
        border-radius: 5px;
    }
    """
    
    with open("static/style.css", "w") as f:
        f.write(style_css)

# Template for homepage
home_html = """
<!DOCTYPE html>
<html>
<head>
    <title>ShahMate Trading Bot</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static', filename='shahmate_logo.png') }}" alt="Shahmate Logo" style="width: 80%; max-width: 300px; margin: 20px auto; display: block;">
        
        <div class="navbar">
            <a href="{{ url_for('index') }}" class="active">Home</a>
            <a href="{{ url_for('live') }}">Live Mode</a>
            <a href="{{ url_for('backtest') }}">Backtest</a>
            <a href="{{ url_for('recommend') }}">Recommend</a>
            <a href="{{ url_for('api') }}">API Settings</a>
            <a href="{{ url_for('variables') }}">Variables</a>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3>Live Trading</h3>
                <p>Status: <span class="status {% if running_live %}running{% else %}stopped{% endif %}"></span> {{ 'Running' if running_live else 'Stopped' }}</p>
                <a href="{{ url_for('live') }}"><button>Open</button></a>
            </div>
            
            <div class="card">
                <h3>Backtest</h3>
                <p>Status: <span class="status {% if running_backtest %}running{% else %}stopped{% endif %}"></span> {{ 'Running' if running_backtest else 'Stopped' }}</p>
                <a href="{{ url_for('backtest') }}"><button>Open</button></a>
            </div>
            
            <div class="card">
                <h3>Recommend</h3>
                <p>Find the best trading opportunities</p>
                <a href="{{ url_for('recommend') }}"><button>Open</button></a>
            </div>
            
            <div class="card">
                <h3>API Settings</h3>
                <p>Configure your Binance API</p>
                <a href="{{ url_for('api') }}"><button>Open</button></a>
            </div>
        </div>
        
        <div class="bot-output">
            {% for msg in bot_output %}
                <div>{{ msg }}</div>
            {% endfor %}
        </div>
        
        <div class="footer">
            ShahMate Trading Bot &copy; 2025
        </div>
    </div>
</body>
</html>
"""

# Template for live mode
live_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Live Trading - ShahMate</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="30">
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static', filename='shahmate_logo.png') }}" alt="Shahmate Logo" style="width: 80%; max-width: 300px; margin: 20px auto; display: block;">
        
        <div class="navbar">
            <a href="{{ url_for('index') }}">Home</a>
            <a href="{{ url_for('live') }}" class="active">Live Mode</a>
            <a href="{{ url_for('backtest') }}">Backtest</a>
            <a href="{{ url_for('recommend') }}">Recommend</a>
            <a href="{{ url_for('api') }}">API Settings</a>
            <a href="{{ url_for('variables') }}">Variables</a>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3>USDT Balance</h3>
                <p>{{ usdt_balance }}</p>
            </div>
            
            <div class="card">
                <h3>USDC Balance</h3>
                <p>{{ usdc_balance }}</p>
            </div>
            
            <div class="card">
                <h3>FDUSD Balance</h3>
                <p>{{ fdusd_balance }}</p>
            </div>
            
            <div class="card">
                <h3>Status</h3>
                <p><span class="status {% if running_live %}running{% else %}stopped{% endif %}"></span> {{ 'Running' if running_live else 'Stopped' }}</p>
            </div>
        </div>
        
        <form method="POST">
            <select name="pair">
                {% for pair in usdt_pairs %}
                    <option value="{{ pair }}" {% if pair == current_pair %}selected{% endif %}>{{ pair }}</option>
                {% endfor %}
            </select>
            
            <select name="interval">
                {% for inter in intervals %}
                    <option value="{{ inter }}" {% if inter == current_interval %}selected{% endif %}>{{ inter }}</option>
                {% endfor %}
            </select>
            
            {% if running_live %}
                <button type="submit" name="action" value="stop">Stop Trading</button>
            {% else %}
                <button type="submit" name="action" value="start">Start Trading</button>
            {% endif %}
        </form>
        
        <div class="bot-output">
            {% for msg in bot_output %}
                <div>{{ msg }}</div>
            {% endfor %}
        </div>
        
        <div class="footer">
            ShahMate Trading Bot &copy; 2025
        </div>
    </div>
</body>
</html>
"""

# Template for backtest
backtest_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Backtest - ShahMate</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.plot.ly/plotly-2.29.0.min.js"></script>
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static', filename='shahmate_logo.png') }}" alt="Shahmate Logo" style="width: 80%; max-width: 300px; margin: 20px auto; display: block;">
        
        <div class="navbar">
            <a href="{{ url_for('index') }}">Home</a>
            <a href="{{ url_for('live') }}">Live Mode</a>
            <a href="{{ url_for('backtest') }}" class="active">Backtest</a>
            <a href="{{ url_for('recommend') }}">Recommend</a>
            <a href="{{ url_for('api') }}">API Settings</a>
            <a href="{{ url_for('variables') }}">Variables</a>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3>Initial USDT</h3>
                <p>{{ current_total_money }}</p>
            </div>
            
            <div class="card">
                <h3>Status</h3>
                <p><span class="status {% if running_backtest %}running{% else %}stopped{% endif %}"></span> {{ 'Running' if running_backtest else 'Stopped' }}</p>
            </div>
            
            {% if backtest_results %}
            <div class="card">
                <h3>Final Balance</h3>
                <p>{{ backtest_results.final_balance }}</p>
            </div>
            
            <div class="card">
                <h3>Profit</h3>
                <p>{{ backtest_results.total_profit }}</p>
            </div>
            
            <div class="card">
                <h3>ROI</h3>
                <p>{{ backtest_results.roi }}%</p>
            </div>
            
            <div class="card">
                <h3>Win Rate</h3>
                <p>{{ backtest_results.win_rate }}%</p>
            </div>
            {% endif %}
        </div>
        
        <form method="POST">
            <select name="pair">
                {% for pair in usdt_pairs %}
                    <option value="{{ pair }}" {% if pair == current_pair %}selected{% endif %}>{{ pair }}</option>
                {% endfor %}
            </select>
            
            <select name="interval">
                {% for inter in intervals %}
                    <option value="{{ inter }}" {% if inter == current_interval %}selected{% endif %}>{{ inter }}</option>
                {% endfor %}
            </select>
            
            <input type="date" name="start_date" value="{{ start_date }}" max="{{ today_date }}">
            <input type="date" name="end_date" value="{{ end_date }}" max="{{ today_date }}">
            
            {% if running_backtest %}
                <button type="submit" name="action" value="stop">Stop Backtest</button>
            {% else %}
                <button type="submit" name="action" value="start">Start Backtest</button>
            {% endif %}
        </form>
        
        {% if chart_div %}
        <div class="chart-container">
            {{ chart_div|safe }}
        </div>
        {% endif %}
        
        <div class="bot-output">
            {% for msg in bot_output %}
                <div>{{ msg }}</div>
            {% endfor %}
        </div>
        
        <div class="footer">
            ShahMate Trading Bot &copy; 2025
        </div>
    </div>
</body>
</html>
"""

# Template for API settings
api_html = """
<!DOCTYPE html>
<html>
<head>
    <title>API Settings - ShahMate</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static', filename='shahmate_logo.png') }}" alt="Shahmate Logo" style="width: 80%; max-width: 300px; margin: 20px auto; display: block;">
        
        <div class="navbar">
            <a href="{{ url_for('index') }}">Home</a>
            <a href="{{ url_for('live') }}">Live Mode</a>
            <a href="{{ url_for('backtest') }}">Backtest</a>
            <a href="{{ url_for('recommend') }}">Recommend</a>
            <a href="{{ url_for('api') }}" class="active">API Settings</a>
            <a href="{{ url_for('variables') }}">Variables</a>
        </div>
        
        <form method="POST">
            <div style="text-align: left; margin-bottom: 20px;">
                <p><strong>API Key:</strong> <input type="text" name="api_key" value="{{ api_key }}" style="width: 100%;"></p>
                <p><strong>API Secret:</strong> <input type="password" name="api_secret" value="{{ api_secret }}" style="width: 100%;"></p>
            </div>
            
            <button type="submit">Save API Settings</button>
        </form>
        
        <div class="bot-output">
            {% for msg in bot_output %}
                <div>{{ msg }}</div>
            {% endfor %}
        </div>
        
        <div class="footer">
            ShahMate Trading Bot &copy; 2025
        </div>
    </div>
</body>
</html>
"""

# Template for variables
variables_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Variables - ShahMate</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static', filename='shahmate_logo.png') }}" alt="Shahmate Logo" style="width: 80%; max-width: 300px; margin: 20px auto; display: block;">
        
        <div class="navbar">
            <a href="{{ url_for('index') }}">Home</a>
            <a href="{{ url_for('live') }}">Live Mode</a>
            <a href="{{ url_for('backtest') }}">Backtest</a>
            <a href="{{ url_for('recommend') }}">Recommend</a>
            <a href="{{ url_for('api') }}">API Settings</a>
            <a href="{{ url_for('variables') }}" class="active">Variables</a>
        </div>
        
        {% if not unlocked %}
            <form method="POST">
                <p>Enter password to edit variables:</p>
                <input type="password" name="password">
                <button type="submit" name="action" value="unlock">Unlock</button>
            </form>
        {% else %}
            <form method="POST">
                <div style="text-align: left;">
                    <p><strong>RSI Length:</strong> <input type="number" name="rsi_length" value="{{ rsi_length }}" min="2" max="50"></p>
                    <p><strong>Oversold Level:</strong> <input type="number" name="oversold_level" value="{{ oversold_level }}" min="1" max="49"></p>
                    <p><strong>Overbought Level:</strong> <input type="number" name="overbought_level" value="{{ overbought_level }}" min="51" max="99"></p>
                    <p><strong>Proximity Range %:</strong> <input type="number" name="proximity_range_percent" value="{{ proximity_range_percent }}" min="0.1" max="10" step="0.1"></p>
                    <p><strong>Profit Range %:</strong> <input type="number" name="profit_range" value="{{ profit_range }}" min="0.1" max="10" step="0.1"></p>
                    <p><strong>Max Buy Steps:</strong> <input type="number" name="max_buy_steps" value="{{ max_buy_steps }}" min="1" max="50"></p>
                    <p><strong>Default Interval:</strong> 
                        <select name="interval">
                            {% for inter in intervals %}
                                <option value="{{ inter }}" {% if inter == interval %}selected{% endif %}>{{ inter }}</option>
                            {% endfor %}
                        </select>
                    </p>
                    <p><strong>EMA Period:</strong> <input type="number" name="ema_period" value="{{ ema_period }}" min="3" max="50"></p>
                    <p><strong>Trailing Start RSI:</strong> <input type="number" name="trailing_start_rsi" value="{{ trailing_start_rsi }}" min="50" max="99"></p>
                    <p><strong>Trailing Stop:</strong> 
                        <select name="trailing_stop_enabled">
                            <option value="1" {% if trailing_stop_enabled %}selected{% endif %}>Enabled</option>
                            <option value="0" {% if not trailing_stop_enabled %}selected{% endif %}>Disabled</option>
                        </select>
                    </p>
                    <p><strong>RSI Threshold:</strong> <input type="number" name="rsi_threshold" value="{{ rsi_threshold }}" min="1" max="50"></p>
                    <p><strong>Price Change Threshold %:</strong> <input type="number" name="price_change_threshold" value="{{ price_change_threshold }}" min="0.1" max="10" step="0.1"></p>
                    <p><strong>Volume Change Threshold:</strong> <input type="number" name="volume_change_threshold" value="{{ volume_change_threshold }}" min="0.1" max="10" step="0.1"></p>
                    <p><strong>Volatility Threshold:</strong> <input type="number" name="volatility_threshold" value="{{ volatility_threshold }}" min="0.1" max="10" step="0.1"></p>
                </div>
                
                <button type="submit" name="action" value="save">Save Variables</button>
                <button type="submit" name="action" value="lock">Lock</button>
            </form>
        {% endif %}
        
        <div class="bot-output">
            {% for msg in bot_output %}
                <div>{{ msg }}</div>
            {% endfor %}
        </div>
        
        <div class="footer">
            ShahMate Trading Bot &copy; 2025
        </div>
    </div>
</body>
</html>
"""

# Template for recommend
recommend_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Recommend - ShahMate</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static', filename='shahmate_logo.png') }}" alt="Shahmate Logo" style="width: 80%; max-width: 300px; margin: 20px auto; display: block;">
        
        <div class="navbar">
            <a href="{{ url_for('index') }}">Home</a>
            <a href="{{ url_for('live') }}">Live Mode</a>
            <a href="{{ url_for('backtest') }}">Backtest</a>
            <a href="{{ url_for('recommend') }}" class="active">Recommend</a>
            <a href="{{ url_for('api') }}">API Settings</a>
            <a href="{{ url_for('variables') }}">Variables</a>
        </div>
        
        <form method="POST">
            <p>Find coins with good trading setup based on current strategy variables</p>
            <button type="submit" name="action" value="recommend">Find Recommendations</button>
        </form>
        
        {% if recommended_coins %}
            <table>
                <tr>
                    <th>Symbol</th>
                    <th>RSI</th>
                    <th>Price</th>
                    <th>24h Change</th>
                    <th>EMA Verified</th>
                    <th>Action</th>
                </tr>
                {% for coin in recommended_coins %}
                <tr>
                    <td>{{ coin.symbol }}</td>
                    <td>{{ coin.rsi|round(2) }}</td>
                    <td>{{ coin.price }}</td>
                    <td>{{ coin.change_24h|round(2) }}%</td>
                    <td>{{ 'Yes' if coin.ema_verified else 'No' }}</td>
                    <td>
                        <a href="{{ url_for('live', pair=coin.symbol) }}"><button>Trade</button></a>
                        <a href="{{ url_for('backtest', pair=coin.symbol) }}"><button>Backtest</button></a>
                    </td>
                </tr>
                {% endfor %}
            </table>
        {% endif %}
        
        <div class="bot-output">
            {% for msg in bot_output %}
                <div>{{ msg }}</div>
            {% endfor %}
        </div>
        
        <div class="footer">
            ShahMate Trading Bot &copy; 2025
        </div>
    </div>
</body>
</html>
"""

# Function to add bot output messages
def add_bot_output(message, context=None):
    global live_output, backtest_output, recommend_output, general_output
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    
    # Add context prefix if provided
    if context == "live":
        prefix = "🔴 LIVE"
        formatted_message = f"{timestamp}: {prefix}: {message}"
        live_output.append(formatted_message)
        if len(live_output) > MAX_OUTPUT:
            live_output = live_output[-MAX_OUTPUT:]
    elif context == "backtest":
        prefix = "📊 BACKTEST"
        formatted_message = f"{timestamp}: {prefix}: {message}"
        backtest_output.append(formatted_message)
        if len(backtest_output) > MAX_OUTPUT:
            backtest_output = backtest_output[-MAX_OUTPUT:]
    elif context == "recommend":
        prefix = "🔍 RECOMMEND"
        formatted_message = f"{timestamp}: {prefix}: {message}"
        recommend_output.append(formatted_message)
        if len(recommend_output) > MAX_OUTPUT:
            recommend_output = recommend_output[-MAX_OUTPUT:]
    else:
        prefix = "ℹ️ INFO"
        formatted_message = f"{timestamp}: {prefix}: {message}"
        general_output.append(formatted_message)
        if len(general_output) > MAX_OUTPUT:
            general_output = general_output[-MAX_OUTPUT:]
    
    # Also log to file
    logging.info(f"{prefix}: {message}")

# Initialize Binance client
def initialize_client():
    global client, api_key, api_secret
    
    # List of different Binance API endpoints to try
    endpoints = [
        # Default endpoint
        {'base_url': 'https://api.binance.com', 'label': 'Global API'},
        # Regional endpoints
        {'base_url': 'https://api1.binance.com', 'label': 'Global API (Alternative 1)'},
        {'base_url': 'https://api2.binance.com', 'label': 'Global API (Alternative 2)'},
        {'base_url': 'https://api3.binance.com', 'label': 'Global API (Alternative 3)'},
        # Regional APIs
        {'base_url': 'https://api.binance.us', 'label': 'US API'},
        {'base_url': 'https://api-gcp.binance.com', 'label': 'GCP API'},
    ]
    
    # First try to connect with proper API keys if provided
    if api_key and api_secret:
        for endpoint in endpoints:
            try:
                add_bot_output(f"Trying connection to {endpoint['label']}...", context="api")
                # Try to connect with specified API key and base URL
                client = Client(api_key, api_secret, base_url=endpoint['base_url'])
                # Test with a simple authenticated API call
                usdt_balance = get_spot_balance().get('USDT', 0)
                add_bot_output(f"✅ Connected to Binance ({endpoint['label']}) with USDT balance: {usdt_balance}", context="api")
                return True
            except Exception as e:
                add_bot_output(f"❌ Failed to connect to {endpoint['label']}: {str(e)}", context="api")
                # Continue to next endpoint
        add_bot_output("Failed to connect with API keys on all endpoints", context="api")
    else:
        add_bot_output("No API keys provided. Trying public access.", context="api")
    
    # Try public API access without authentication on different endpoints
    for endpoint in endpoints:
        try:
            add_bot_output(f"Attempting public-only access on {endpoint['label']}...", context="api")
            client = Client("", "", base_url=endpoint['base_url'])  # Empty strings for public endpoints
            
            # Test connection with simple API call that doesn't need authentication
            test = client.get_exchange_info()
            if test:
                add_bot_output(f"✅ Connected to Binance ({endpoint['label']}) with public-only access", context="api")
                return True
        except Exception as e:
            add_bot_output(f"❌ Failed public-only access on {endpoint['label']}: {str(e)}", context="api")
    
    # Final fallback: Simulation mode without any API connection
    add_bot_output("⚠️ Geographic API restrictions detected - using SIMULATION MODE", context="api")
    add_bot_output("All API calls will be simulated. No real trading will occur.", context="api")
    add_bot_output("Data shown will be for demonstration purposes only.", context="api")
    client = None  # Set client to None to indicate simulation mode
    return True  # Return True so the application can still function in simulation mode

# Get all USDT trading pairs
def get_usdt_pairs():
    global usdt_pairs
    
    # Always try to get a fresh list first to ensure we have the latest pairs
    try:
        # First attempt: Use authenticated client
        if client:
            try:
                # Get exchange info from authenticated client
                exchange_info = client.get_exchange_info()
                
                # Filter for USDT pairs
                updated_pairs = [s['symbol'] for s in exchange_info['symbols'] 
                               if s['symbol'].endswith('USDT') and s['status'] == 'TRADING']
                
                # Check if list has changed
                if updated_pairs and (not usdt_pairs or set(updated_pairs) != set(usdt_pairs)):
                    usdt_pairs = updated_pairs
                    add_bot_output(f"Updated to {len(usdt_pairs)} USDT trading pairs from Binance API", context="api")
                    
                # Successfully got pairs, so return early
                usdt_pairs.sort()
                return usdt_pairs
            except Exception as e:
                add_bot_output(f"Failed to get pairs using authenticated client: {str(e)}", context="api")
                # Continue to next attempt
        
        # Second attempt: Public API
        try:
            url = "https://api.binance.com/api/v3/exchangeInfo"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                updated_pairs = [s['symbol'] for s in data['symbols'] 
                               if s['symbol'].endswith('USDT') and s['status'] == 'TRADING']
                
                # Check if list has changed
                if updated_pairs and (not usdt_pairs or set(updated_pairs) != set(usdt_pairs)):
                    usdt_pairs = updated_pairs
                    add_bot_output(f"Updated to {len(usdt_pairs)} USDT trading pairs using public API", context="api")
                
                # Successfully got pairs, so return early
                usdt_pairs.sort()
                return usdt_pairs
            else:
                add_bot_output(f"Failed to get trading pairs from public API: {response.status_code}", context="api")
                # Continue to fallback
        except Exception as e:
            add_bot_output(f"Failed to get pairs using public API: {str(e)}", context="api")
            # Continue to fallback
        
        # Third attempt: Try CoinGecko API as an alternative public source
        try:
            # Using CoinGecko as a fallback option for asset list
            url = "https://api.coingecko.com/api/v3/coins/markets"
            params = {
                "vs_currency": "usd",  # Using USD as base currency
                "order": "market_cap_desc",  # Sort by market cap
                "per_page": 250,  # Get top coins
                "page": 1,
                "sparkline": "false",
            }
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                # Format symbols as they would appear on Binance
                updated_pairs = [f"{coin['symbol'].upper()}USDT" for coin in data if coin['symbol']]
                
                # Check if list has meaningful changes
                if updated_pairs and (not usdt_pairs or abs(len(updated_pairs) - len(usdt_pairs)) > 5):
                    usdt_pairs = updated_pairs
                    add_bot_output(f"Updated to {len(usdt_pairs)} USDT trading pairs from CoinGecko API", context="api")
                
                # Successfully got pairs, so return early
                usdt_pairs.sort()
                return usdt_pairs
            else:
                add_bot_output(f"Failed to get coins from CoinGecko API: {response.status_code}", context="api")
                # Continue to fallback
        except Exception as e:
            add_bot_output(f"Failed to get coins from CoinGecko: {str(e)}", context="api")
            # Continue to fallback
                    
    except Exception as e:
        add_bot_output(f"Error in get_usdt_pairs: {str(e)}", context="api")
        # Continue to fallback
    
    # Final fallback: Use comprehensive default list
    # If we already have a list, keep using it
    if usdt_pairs:
        add_bot_output(f"Using existing list of {len(usdt_pairs)} trading pairs", context="api")
    else:
        # Expanded comprehensive fallback list of top trading pairs
        usdt_pairs = [
            "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT", "DOGEUSDT", "XRPUSDT", 
            "AVAXUSDT", "DOTUSDT", "LTCUSDT", "LINKUSDT", "MATICUSDT", "TRXUSDT", "UNIUSDT",
            "SHIBUSDT", "ATOMUSDT", "VETUSDT", "MANAUSDT", "ETCUSDT", "ICPUSDT", "FILUSDT",
            "FTMUSDT", "NEARUSDT", "ALICEUSDT", "AAVEUSDT", "APEUSDT", "SANDUSDT", "XMRUSDT",
            "LRCUSDT", "THETAUSDT", "HBARUSDT", "RUNEUSDT", "DASHUSDT", "CHZUSDT", "ENUSDT", 
            "STXUSDT", "ZILUSDT", "LPTUSDT", "XLMUSDT", "BATUSDT", "EOSUSDT", "DYDXUSDT",
            "SNXUSDT", "EGLDUSDT", "1INCHUSDT", "WAVESUSDT", "ENJUSDT", "KAVAUSDT", "MKRUSDT"
        ]
        add_bot_output(f"Using comprehensive fallback list of {len(usdt_pairs)} common USDT trading pairs", context="api")
    
    # Always sort the list for consistent display
    usdt_pairs.sort()
    return usdt_pairs

# Get account balances
def get_spot_balance():
    if client:
        try:
            account = client.get_account()
            balances = {}
            for balance in account['balances']:
                asset = balance['asset']
                free = float(balance['free'])
                locked = float(balance['locked'])
                total = free + locked
                if total > 0:
                    balances[asset] = total
            add_bot_output(f"Successfully fetched real balances from Binance", context="live")
            return balances
        except Exception as e:
            add_bot_output(f"Error getting balances: {str(e)}", context="live")
            # Return simulated balances as fallback with an indicator
            simulated = {"USDT": 15000, "USDC": 5000, "FDUSD": 0}
            add_bot_output("⚠️ Using simulated balances due to API connection issues", context="live")
            return simulated
    else:
        # Return simulated balances if client not initialized with an indicator
        simulated = {"USDT": 15000, "USDC": 5000, "FDUSD": 0}
        add_bot_output("⚠️ Using simulated balances (no API connection)", context="live")
        return simulated

# Function to place a market buy order
def place_market_buy_order(symbol, quantity):
    if client:
        try:
            order = client.create_order(
                symbol=symbol,
                side=SIDE_BUY,
                type=ORDER_TYPE_MARKET,
                quantity=quantity)
            add_bot_output(f"✅ BUY order placed for {quantity} {symbol}", context="live")
            return order
        except Exception as e:
            add_bot_output(f"❌ Buy order error: {str(e)}", context="live")
            return None
    else:
        # Simulated order response for testing
        add_bot_output(f"🔄 SIMULATED buy for {quantity} {symbol}", context="live")
        return {
            "symbol": symbol,
            "orderId": 12345,
            "status": "FILLED",
            "type": "MARKET",
            "side": "BUY",
            "price": "0",
            "origQty": str(quantity),
            "executedQty": str(quantity),
            "cummulativeQuoteQty": "0",
            "fills": []
        }

# Function to place a market sell order
def place_market_sell_order(symbol, quantity):
    if client:
        try:
            order = client.create_order(
                symbol=symbol,
                side=SIDE_SELL,
                type=ORDER_TYPE_MARKET,
                quantity=quantity)
            add_bot_output(f"✅ SELL order placed for {quantity} {symbol}", context="live")
            return order
        except Exception as e:
            add_bot_output(f"❌ Sell order error: {str(e)}", context="live")
            return None
    else:
        # Simulated order response for testing
        add_bot_output(f"🔄 SIMULATED sell for {quantity} {symbol}", context="live")
        return {
            "symbol": symbol,
            "orderId": 12345,
            "status": "FILLED",
            "type": "MARKET",
            "side": "SELL",
            "price": "0",
            "origQty": str(quantity),
            "executedQty": str(quantity),
            "cummulativeQuoteQty": "0",
            "fills": []
        }

# Convert USDC to USDT
def convert_usdc_to_usdt(amount):
    if client:
        try:
            # This is a placeholder - actual implementation would depend on Binance's API
            add_bot_output(f"Converting {amount} USDC to USDT", context="live")
            # In a real implementation, you would use Binance's API to convert
            return True
        except Exception as e:
            add_bot_output(f"❌ Error converting USDC to USDT: {str(e)}", context="live")
            return False
    else:
        add_bot_output(f"🔄 SIMULATED conversion of {amount} USDC to USDT", context="live")
        return True

# Convert USDT to FDUSD
def convert_usdt_to_fdusd(amount):
    if client:
        try:
            # This is a placeholder - actual implementation would depend on Binance's API
            add_bot_output(f"Converting {amount} USDT to FDUSD", context="live")
            # In a real implementation, you would use Binance's API to convert
            return True
        except Exception as e:
            add_bot_output(f"❌ Error converting USDT to FDUSD: {str(e)}", context="live")
            return False
    else:
        add_bot_output(f"🔄 SIMULATED conversion of {amount} USDT to FDUSD", context="live")
        return True

# Function to generate simulated historical klines (for simulation mode)
def generate_simulated_klines(symbol, interval, limit=1000, start_time=None, end_time=None):
    """
    Generate simulated historical data for testing when no API access is available.
    Ensures statistically realistic price movements with volatility based on the symbol.
    """
    add_bot_output(f"Generating simulated data for {symbol} in SIMULATION MODE", context="backtest")
    
    # Base volatility factors based on common crypto assets
    volatility_factors = {
        "BTCUSDT": 0.025,   # BTC is less volatile
        "ETHUSDT": 0.035,   # ETH is moderately volatile
        "BNBUSDT": 0.04,    # BNB is moderately volatile
        "SOLUSDT": 0.055,   # SOL is more volatile
        "DOGEUSDT": 0.08,   # DOGE is highly volatile
        "XRPUSDT": 0.05,    # XRP is moderately volatile
    }
    
    # Default volatility if specific symbol not found
    volatility = volatility_factors.get(symbol, 0.045)  # 4.5% average volatility
    
    # Set reasonable base price based on symbol
    if "BTC" in symbol:
        base_price = 45000 + (random.random() * 10000)
    elif "ETH" in symbol:
        base_price = 2500 + (random.random() * 1000)
    elif "BNB" in symbol:
        base_price = 350 + (random.random() * 50)
    elif "SOL" in symbol:
        base_price = 120 + (random.random() * 20)
    elif "DOGE" in symbol:
        base_price = 0.1 + (random.random() * 0.05)
    elif "XRP" in symbol:
        base_price = 0.5 + (random.random() * 0.2)
    else:
        # For other coins, generate a reasonable random price
        magnitude = random.choice([0.1, 1, 10, 100])
        base_price = magnitude * (1 + random.random())
    
    # Determine the candle duration in seconds based on interval
    seconds_map = {
        "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
        "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "8h": 28800,
        "12h": 43200, "1d": 86400, "3d": 259200, "1w": 604800
    }
    candle_seconds = seconds_map.get(interval, 3600)  # Default to 1h
    
    # Set proper time range
    if not end_time:
        end_time = int(time.time() * 1000)  # Current time in milliseconds
    if not start_time:
        # Calculate start time based on limit and interval
        start_time = end_time - (candle_seconds * 1000 * limit)
    
    # Initialize simulated data points
    klines = []
    current_price = base_price
    current_time = start_time
    
    # Generate data points
    for i in range(limit):
        # Random price movement with volatility factor
        price_change_pct = random.normalvariate(0, volatility)
        price_change = current_price * price_change_pct
        
        # Calculate prices
        open_price = current_price
        close_price = current_price + price_change
        high_price = max(open_price, close_price) * (1 + abs(random.normalvariate(0, volatility/2)))
        low_price = min(open_price, close_price) * (1 - abs(random.normalvariate(0, volatility/2)))
        
        # Generate volume (larger when price changes more)
        base_volume = abs(price_change) * 1000 * (1 + random.random())
        volume = max(base_volume, 100)  # Ensure some minimum volume
        
        # Create kline data in Binance format
        kline = [
            current_time,                           # Open time
            f"{open_price:.8f}",                    # Open
            f"{high_price:.8f}",                    # High
            f"{low_price:.8f}",                     # Low
            f"{close_price:.8f}",                   # Close
            f"{volume:.8f}",                        # Volume
            current_time + (candle_seconds * 1000), # Close time
            f"{volume * open_price:.8f}",           # Quote asset volume
            100,                                    # Number of trades
            f"{volume * 0.4:.8f}",                  # Taker buy base asset volume
            f"{volume * 0.4 * open_price:.8f}",     # Taker buy quote asset volume
            "0"                                     # Ignore
        ]
        
        klines.append(kline)
        
        # Update for next iteration
        current_price = close_price
        current_time += candle_seconds * 1000
    
    add_bot_output(f"Generated {len(klines)} simulated candles for {symbol}", context="backtest")
    return klines

# Function to get historical klines (candles)
def get_historical_klines(symbol, interval, limit=1000, start_time=None, end_time=None):
    try:
        # First try: Use authenticated client if available
        if client:
            try:
                klines = client.get_historical_klines(
                    symbol=symbol, 
                    interval=interval, 
                    limit=limit,
                    start_str=start_time,
                    end_str=end_time
                )
                add_bot_output(f"Retrieved {len(klines)} candles from Binance API", context="backtest")
                return klines
            except Exception as e:
                add_bot_output(f"Error with authenticated API for klines: {str(e)}", context="backtest")
                # Fall through to next attempt
        
        # Second try: Public API without authentication
        try:
            url = "https://api.binance.com/api/v3/klines"
            params = {
                "symbol": symbol,
                "interval": interval,
                "limit": limit
            }
            if start_time:
                params["startTime"] = start_time
            if end_time:
                params["endTime"] = end_time
                
            response = requests.get(url, params=params)
            if response.status_code == 200:
                klines = response.json()
                add_bot_output(f"Retrieved {len(klines)} candles from public API", context="backtest")
                return klines
            else:
                add_bot_output(f"Failed to get klines from public API: {response.status_code}", context="backtest")
                # Fall through to simulation
        except Exception as e:
            add_bot_output(f"Error with public API for klines: {str(e)}", context="backtest")
            # Fall through to simulation
        
        # Final fallback: Generate simulated data
        add_bot_output("Using simulation mode for price data", context="backtest")
        return generate_simulated_klines(symbol, interval, limit, start_time, end_time)
            
    except Exception as e:
        add_bot_output(f"Critical error getting klines: {str(e)}", context="backtest")
        # Generate simulated data as last resort
        return generate_simulated_klines(symbol, interval, limit, start_time, end_time)

# Function to get live market data
def get_live_data(symbol, interval):
    global last_ws_message
    
    try:
        # Try to use WebSocket data first if available
        if last_ws_message and 'k' in last_ws_message:
            kline_data = last_ws_message['k']
            current_price = float(kline_data['c'])  # Current close price
            
            # Log WebSocket data usage
            add_bot_output(f"Using WebSocket data: {symbol} at {current_price}", context="live")
            
            # Still need historical data for indicators
            klines = get_historical_klines(symbol, interval, limit=100)
            
            if not klines:
                add_bot_output(f"No klines data received for {symbol}")
                return None
                
            # Parse klines data
            open_time = [int(entry[0]) for entry in klines]
            open_price = [float(entry[1]) for entry in klines]
            high_price = [float(entry[2]) for entry in klines]
            low_price = [float(entry[3]) for entry in klines]
            close_price = [float(entry[4]) for entry in klines]
            volume = [float(entry[5]) for entry in klines]
            
            # Update last price with WebSocket data
            close_price[-1] = current_price
        else:
            # Fallback to REST API if WebSocket data is not available
            add_bot_output("WebSocket data not available, using REST API", context="live")
            
            # Get recent klines (candlesticks)
            klines = get_historical_klines(symbol, interval, limit=100)
            
            if not klines:
                add_bot_output(f"No klines data received for {symbol}")
                return None
                
            # Parse klines data
            open_time = [int(entry[0]) for entry in klines]
            open_price = [float(entry[1]) for entry in klines]
            high_price = [float(entry[2]) for entry in klines]
            low_price = [float(entry[3]) for entry in klines]
            close_price = [float(entry[4]) for entry in klines]
            volume = [float(entry[5]) for entry in klines]
            
            # Get ticker price for current price
            if client:
                ticker = client.get_symbol_ticker(symbol=symbol)
                current_price = float(ticker['price'])
            else:
                # Use the last close price if client is not available
                current_price = close_price[-1]
        
        # Calculate RSI
        rsi_value = calculate_rsi(close_price)
        
        # Calculate EMA
        ema_value = calculate_ema(close_price)
        
        # Check if price is above EMA (a simple trend confirmation)
        ema_verified = current_price > ema_value[-1] if ema_value else False
        
        return {
            'symbol': symbol,
            'current_price': current_price,
            'close_prices': close_price,
            'rsi': rsi_value[-1] if rsi_value else None,
            'ema': ema_value[-1] if ema_value else None,
            'ema_verified': ema_verified
        }
    except Exception as e:
        add_bot_output(f"Error getting live data: {str(e)}")
        logging.error(f"Error getting live data: {str(e)}")
        return None

# Calculate Relative Strength Index (RSI)
def calculate_rsi(prices, length=None):
    if length is None:
        length = rsi_length
        
    if len(prices) < length + 1:
        return None
        
    # Calculate price changes
    deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
    
    # Calculate gains and losses
    gains = [delta if delta > 0 else 0 for delta in deltas]
    losses = [-delta if delta < 0 else 0 for delta in deltas]
    
    # Calculate average gains and losses
    avg_gain = sum(gains[:length]) / length
    avg_loss = sum(losses[:length]) / length
    
    # Calculate subsequent average gains and losses
    rsi_values = []
    for i in range(length, len(deltas)):
        avg_gain = (avg_gain * (length - 1) + gains[i]) / length
        avg_loss = (avg_loss * (length - 1) + losses[i]) / length
        
        if avg_loss == 0:
            rs = 100
        else:
            rs = avg_gain / avg_loss
            
        rsi = 100 - (100 / (1 + rs))
        rsi_values.append(rsi)
    
    return rsi_values

# Calculate Exponential Moving Average (EMA)
def calculate_ema(prices, period=None):
    if period is None:
        period = ema_period
        
    if len(prices) < period:
        return None
        
    ema_values = []
    multiplier = 2 / (period + 1)
    
    # Start with SMA for the first EMA value
    sma = sum(prices[:period]) / period
    ema_values.append(sma)
    
    # Calculate EMA for remaining prices
    for price in prices[period:]:
        ema = (price - ema_values[-1]) * multiplier + ema_values[-1]
        ema_values.append(ema)
    
    return ema_values

# WebSocket functions for real-time market data
def on_ws_message(ws, message):
    global last_ws_message
    try:
        data = json.loads(message)
        last_ws_message = data
        # Add to logs for debugging
        logging.info(f"WebSocket message received: {data}")
    except Exception as e:
        add_bot_output(f"WebSocket message error: {str(e)}")
        logging.error(f"WebSocket message error: {str(e)}")

def on_ws_error(ws, error):
    add_bot_output(f"WebSocket error: {str(error)}")
    logging.error(f"WebSocket error: {str(error)}")

def on_ws_close(ws, close_status_code, close_msg):
    add_bot_output("WebSocket connection closed")
    logging.info("WebSocket connection closed")

def on_ws_open(ws):
    add_bot_output("WebSocket connection opened")
    logging.info("WebSocket connection opened")

def start_kline_socket(symbol, interval):
    global ws_app
    
    # Close existing connection if any
    if ws_app:
        ws_app.close()
    
    # Format symbol to lowercase
    symbol = symbol.lower()
    
    # Binance WebSocket URL for kline data
    socket_url = f"wss://stream.binance.com:9443/ws/{symbol}@kline_{interval}"
    
    # Create WebSocket connection
    ws_app = websocket.WebSocketApp(
        socket_url,
        on_message=on_ws_message,
        on_error=on_ws_error,
        on_close=on_ws_close,
        on_open=on_ws_open
    )
    
    # Start WebSocket connection in a separate thread
    websocket_thread = Thread(target=ws_app.run_forever, kwargs={"sslopt": {"cert_reqs": ssl.CERT_NONE}})
    websocket_thread.daemon = True  # Daemon thread to exit when main thread exits
    websocket_thread.start()
    
    add_bot_output(f"Started kline socket for {symbol} with {interval} interval")
    return websocket_thread

# Function to run live trading
def run_live(symbol, interval):
    global running_live, current_total_money, total_spent, total_coins, buy_counter, last_buy_price, base_amount, avg_price
    global trailing_active, trailing_peak_rsi, trailing_peak_value
    
    add_bot_output(f"Starting live trading for {symbol} with {interval} interval", context="live")
    
    # Get initial balance
    balance = get_spot_balance()
    current_total_money = balance.get("USDT", 0)
    
    if current_total_money <= 0:
        add_bot_output("No USDT balance available!", context="live")
        running_live = False
        return
    
    # Reset trading variables
    total_spent = 0
    total_coins = 0
    buy_counter = 0
    last_buy_price = None
    base_amount = current_total_money / max_buy_steps if max_buy_steps > 0 else 0
    avg_price = 0
    trailing_active = False
    trailing_peak_rsi = 0
    trailing_peak_value = 0
    
    balances = get_spot_balance()
    add_bot_output(f"Current balances: USDT={balances.get('USDT', 0)}, USDC={balances.get('USDC', 0)}, FDUSD={balances.get('FDUSD', 0)}", context="live")
    
    while running_live:
        try:
            # Use improved live trading function from shahmate_strategy
            state, df = shahmate_strategy.run_live_trading(
                symbol=symbol,
                interval=interval,
                length=rsi_length,
                oversold_level=oversold_level,
                overbought_level=overbought_level,
                proximity_range_percent=proximity_range_percent,
                profit_range=profit_range,
                max_buy_steps=max_buy_steps,
                ema_period=ema_period,
                trailing_start_rsi=trailing_start_rsi,
                trailing_stop_enabled=trailing_stop_enabled,
                client=client,
                log_callback=lambda msg: add_bot_output(msg, context="live"),
                place_buy_order=place_market_buy_order,
                place_sell_order=place_market_sell_order,
                get_balances=get_spot_balance
            )
            
            if not state:
                add_bot_output("Failed to get live data, retrying in 30 seconds...", context="live")
                time.sleep(30)
                continue
            
            # Extract current state
            current_price = state['price']
            current_rsi = state['rsi']
            above_ema = state['above_ema']
            current_time = state['time']
            
            # Check for buy signal
            if current_rsi < oversold_level and above_ema and current_total_money > 0:
                # Calculate buy tier
                tier = min(buy_counter + 1, max_buy_steps)
                buy_amount = base_amount * (1 + (tier - 1) * 0.1)  # Increase by 10% for each tier
                
                # Check if price is far enough from last buy
                price_condition = last_buy_price is None or current_price < last_buy_price * (1 - proximity_range_percent / 100)
                
                if buy_amount <= current_total_money and price_condition:
                    add_bot_output(f"BUY SIGNAL: Price: {current_price}, RSI: {current_rsi:.2f}", context="live")
                    
                    # Calculate quantity
                    quantity = buy_amount / current_price
                    
                    # Place order
                    try:
                        order = place_market_buy_order(symbol, quantity)
                        
                        if order:
                            add_bot_output(f"BUY ORDER PLACED: Quantity: {quantity}, Amount: {buy_amount} USDT", context="live")
                            
                            # Update tracking variables
                            buy_counter += 1
                            last_buy_price = current_price
                            total_spent += buy_amount
                            total_coins += quantity
                            current_total_money -= buy_amount
                            avg_price = total_spent / total_coins if total_coins > 0 else 0
                        else:
                            add_bot_output("Failed to place buy order", context="live")
                    except Exception as e:
                        add_bot_output(f"Error placing buy order: {str(e)}", context="live")
            
            # Check for sell signal if we have coins
            if total_coins > 0:
                total_current_value = total_coins * current_price
                profit_percent = ((current_price - avg_price) / avg_price) * 100 if avg_price > 0 else 0
                
                # Check profit target
                profit_target_met = profit_percent >= profit_range
                
                # Check trailing stop activation
                if trailing_stop_enabled and current_rsi > trailing_start_rsi and not trailing_active:
                    trailing_active = True
                    trailing_peak_rsi = current_rsi
                    trailing_peak_value = current_price
                    add_bot_output(f"Trailing stop activated at price {current_price}, RSI {current_rsi}", context="live")
                
                # Update trailing stop if price rises
                if trailing_active and current_price > trailing_peak_value:
                    trailing_peak_value = current_price
                    trailing_peak_rsi = max(trailing_peak_rsi, current_rsi)
                
                # Check trailing stop triggered
                trailing_triggered = trailing_active and (current_price < trailing_peak_value * 0.99 or current_rsi < trailing_peak_rsi * 0.9)
                
                # Check RSI overbought exit
                rsi_exit = current_rsi > overbought_level
                
                # Sell if any sell condition met
                if profit_target_met or trailing_triggered or rsi_exit:
                    reason = "Profit Target" if profit_target_met else "Trailing Stop" if trailing_triggered else "RSI Exit"
                    
                    add_bot_output(f"SELL SIGNAL ({reason}): Price: {current_price}, Profit: {profit_percent:.2f}%", context="live")
                    
                    try:
                        order = place_market_sell_order(symbol, total_coins)
                        
                        if order:
                            add_bot_output(f"SELL ORDER PLACED: Quantity: {total_coins}, Price: {current_price}", context="live")
                            
                            # Update balance and reset position
                            current_total_money += total_current_value
                            total_spent = 0
                            total_coins = 0
                            buy_counter = 0
                            last_buy_price = None
                            avg_price = 0
                            trailing_active = False
                            trailing_peak_rsi = 0
                            trailing_peak_value = 0
                        else:
                            add_bot_output("Failed to place sell order", context="live")
                    except Exception as e:
                        add_bot_output(f"Error placing sell order: {str(e)}", context="live")
            
            # Wait before next check
            time.sleep(30)
            
        except Exception as e:
            add_bot_output(f"Error in live trading: {str(e)}", context="live")
            time.sleep(30)

# Generate a backtest chart with plotly
def generate_backtest_chart(symbol, prices, times, rsi_values, ema_values, buy_points, sell_points):
    try:
        # Create figure with secondary y-axis
        fig = make_subplots(rows=2, cols=1, 
                            shared_xaxes=True, 
                            vertical_spacing=0.05, 
                            row_heights=[0.7, 0.3],
                            subplot_titles=(f"{symbol} Price Chart", "RSI Indicator"))
        
        # Add price line to the first row
        fig.add_trace(
            go.Scatter(
                x=times, 
                y=prices, 
                mode='lines',
                name='Price',
                line=dict(color='#3498db')
            ),
            row=1, col=1
        )
        
        # Add EMA line to the first row
        if ema_values and len(ema_values) > 0:
            # EMA values typically start after a certain period, so we need to align with times
            ema_times = times[-len(ema_values):]
            fig.add_trace(
                go.Scatter(
                    x=ema_times, 
                    y=ema_values, 
                    mode='lines',
                    name=f'EMA-{ema_period}',
                    line=dict(color='#f39c12')
                ),
                row=1, col=1
            )
        
        # Add buy points to the first row
        if buy_points:
            buy_x, buy_y = zip(*buy_points)
            fig.add_trace(
                go.Scatter(
                    x=buy_x, 
                    y=buy_y, 
                    mode='markers',
                    name='Buy',
                    marker=dict(
                        color='#2ecc71',
                        size=10,
                        symbol='triangle-up'
                    )
                ),
                row=1, col=1
            )
        
        # Add sell points to the first row
        if sell_points:
            sell_x, sell_y = zip(*sell_points)
            fig.add_trace(
                go.Scatter(
                    x=sell_x, 
                    y=sell_y, 
                    mode='markers',
                    name='Sell',
                    marker=dict(
                        color='#e74c3c',
                        size=10,
                        symbol='triangle-down'
                    )
                ),
                row=1, col=1
            )
        
        # Add RSI line to the second row
        if rsi_values and len(rsi_values) > 0:
            # RSI values typically start after a certain period, so we need to align with times
            rsi_times = times[-len(rsi_values):]
            fig.add_trace(
                go.Scatter(
                    x=rsi_times, 
                    y=rsi_values, 
                    mode='lines',
                    name='RSI',
                    line=dict(color='#9b59b6')
                ),
                row=2, col=1
            )
            
            # Add horizontal lines for overbought and oversold levels
            fig.add_shape(
                type="line",
                x0=min(times),
                x1=max(times),
                y0=oversold_level,
                y1=oversold_level,
                line=dict(color="#2ecc71", width=1, dash="dash"),
                row=2, col=1
            )
            
            fig.add_shape(
                type="line",
                x0=min(times),
                x1=max(times),
                y0=overbought_level,
                y1=overbought_level,
                line=dict(color="#e74c3c", width=1, dash="dash"),
                row=2, col=1
            )
        
        # Update layout
        fig.update_layout(
            title_text=f"Backtest Results for {symbol}",
            autosize=True,
            height=700,
            template="plotly_dark",
            plot_bgcolor='#2c3e50',
            paper_bgcolor='#2c3e50',
            font=dict(color='#ecf0f1'),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        # Update axes
        fig.update_xaxes(
            title_text="Date",
            showgrid=True,
            gridcolor='#34495e',
            row=2, col=1
        )
        
        fig.update_yaxes(
            title_text="Price",
            showgrid=True,
            gridcolor='#34495e',
            row=1, col=1
        )
        
        fig.update_yaxes(
            title_text="RSI",
            showgrid=True,
            gridcolor='#34495e',
            range=[0, 100],
            row=2, col=1
        )
        
        # Convert plot to HTML
        chart_div = fig.to_html(full_html=False, include_plotlyjs=False)
        return chart_div
    
    except Exception as e:
        add_bot_output(f"Error generating chart: {str(e)}")
        return None

# Function to run backtesting
# Import our strategy module
import shahmate_strategy

def run_backtest(symbol, interval, start_date=None, end_date=None):
    global running_backtest, current_total_money, total_spent, total_coins, buy_counter, last_buy_price, base_amount, avg_price
    global trailing_active, trailing_peak_rsi, trailing_peak_value
    
    # Handle dates for the backtest
    if not start_date or not end_date:
        # Default to last 30 days if dates not provided
        end_date = datetime.now().strftime("%Y-%m-%d")
        start_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    
    add_bot_output(f"Starting backtest for {symbol} with {interval} interval from {start_date} to {end_date}", context="backtest")
    
    try:
        # Call the improved strategy backtesting function
        result = shahmate_strategy.run_backtest(
            symbol=symbol,
            interval=interval,
            initial_balance=current_total_money,
            length=rsi_length,
            oversold_level=oversold_level,
            overbought_level=overbought_level,
            proximity_range_percent=proximity_range_percent,
            profit_range=profit_range,
            max_buy_steps=max_buy_steps,
            ema_period=ema_period,
            trailing_start_rsi=trailing_start_rsi,
            trailing_stop_enabled=trailing_stop_enabled,
            start_date=start_date,
            end_date=end_date,
            client=client,
            log_callback=lambda msg: add_bot_output(msg, context="backtest")
        )
        
        if not result or len(result) < 9:
            add_bot_output("Backtest failed to produce results", context="backtest")
            running_backtest = False
            return None
            
        # Extract results
        times, closes, rsi_series, ema_values, buy_points, sell_points, final_balance, total_profit, roi_percent = result
        
        # Convert times for chart
        chart_dates = [datetime.strptime(t, '%Y-%m-%d %H:%M:%S') for t in times]
        
        # Generate chart
        chart_div = generate_backtest_chart(
            symbol=symbol,
            prices=closes.tolist() if hasattr(closes, 'tolist') else closes,
            times=chart_dates,
            rsi_values=rsi_series.tolist() if hasattr(rsi_series, 'tolist') else rsi_series,
            ema_values=ema_values.tolist() if hasattr(ema_values, 'tolist') else ema_values,
            buy_points=buy_points,
            sell_points=sell_points
        )
        
        # Calculate trade statistics
        buy_count = len(buy_points) if buy_points else 0
        sell_count = len(sell_points) if sell_points else 0
        win_rate = 100 if total_profit > 0 and sell_count > 0 else 0
        
        add_bot_output(f"===== Backtest Complete =====", context="backtest")
        add_bot_output(f"Symbol: {symbol}, Interval: {interval}", context="backtest")
        add_bot_output(f"Initial USDT: {current_total_money}", context="backtest")
        add_bot_output(f"Final USDT: {final_balance}", context="backtest")
        add_bot_output(f"Total profit: {total_profit}", context="backtest")
        add_bot_output(f"ROI: {roi_percent:.2f}%", context="backtest")
        add_bot_output(f"Total trades: {buy_count} buys, {sell_count} sells", context="backtest")
        
        # Return results for display on the web page
        return {
            'chart_div': chart_div,
            'final_balance': f"{final_balance:.2f} USDT",
            'total_profit': f"{total_profit:.2f} USDT",
            'roi': f"{roi_percent:.2f}",
            'win_rate': f"{win_rate:.2f}%",
            'buy_count': buy_count,
            'sell_count': sell_count,
            'winning_trades': sell_count if total_profit > 0 else 0,
            'losing_trades': sell_count if total_profit <= 0 else 0
        }
        
    except Exception as e:
        add_bot_output(f"Error in backtest: {str(e)}", context="backtest")
        running_backtest = False
        return None

# Function to find recommended coins using improved strategy
def run_recommend():
    add_bot_output("Finding recommended coins...", context="recommend")
    
    recommended = []
    pairs = get_usdt_pairs()
    
    # Limit to avoid rate limits
    max_pairs_to_check = min(50, len(pairs))
    
    for i, symbol in enumerate(pairs[:max_pairs_to_check]):
        try:
            # Use our improved strategy to get data
            state, df = shahmate_strategy.run_live_trading(
                symbol=symbol,
                interval=interval,
                length=rsi_length,
                oversold_level=oversold_level,
                overbought_level=overbought_level,
                proximity_range_percent=proximity_range_percent,
                profit_range=profit_range,
                max_buy_steps=max_buy_steps,
                ema_period=ema_period,
                trailing_start_rsi=trailing_start_rsi,
                trailing_stop_enabled=trailing_stop_enabled,
                client=client,
                log_callback=None  # Don't log for recommendations
            )
            
            if not state:
                continue
                
            # Extract the information we need
            current_price = state['price']
            rsi = state['rsi']
            above_ema = state['above_ema']
            
            # Only consider coins with RSI below the threshold
            if rsi < rsi_threshold:
                # Get 24h price change
                if client:
                    try:
                        ticker = client.get_ticker(symbol=symbol)
                        price_change_24h = float(ticker.get('priceChangePercent', 0))
                    except Exception:
                        price_change_24h = 0
                else:
                    price_change_24h = 0  # Default if client not available
                
                # Add to recommended list if it meets the criteria
                if above_ema and (abs(price_change_24h) >= price_change_threshold):
                    recommended.append({
                        'symbol': symbol,
                        'rsi': rsi,
                        'price': current_price,
                        'change_24h': price_change_24h,
                        'ema_verified': above_ema
                    })
                    
                    add_bot_output(f"Found potential: {symbol} - RSI: {rsi:.2f}, Price: {current_price}, Above EMA: {above_ema}", context="recommend")
            
            # Log progress occasionally
            if (i+1) % 5 == 0:
                add_bot_output(f"Checked {i+1}/{max_pairs_to_check} pairs...", context="recommend")
                
        except Exception as e:
            continue  # Silently continue on error for recommend function
    
    # Sort by RSI (lowest first)
    recommended.sort(key=lambda x: x['rsi'])
    
    # Log results
    add_bot_output(f"Found {len(recommended)} recommended coins", context="recommend")
    
    return recommended

# Routes
@app.route('/')
def index():
    get_usdt_pairs()  # Make sure we have the pairs list
    return render_template('home.html', 
                          running_live=running_live, 
                          running_backtest=running_backtest, 
                          general_output=general_output)

@app.route('/live', methods=['GET', 'POST'])
def live():
    global running_live, running_backtest
    
    # Get pairs and balances
    pairs = get_usdt_pairs()
    balances = get_spot_balance()
    
    current_pair = request.args.get('pair', 'BTCUSDT')
    current_interval = request.args.get('interval', interval)
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'start':
            # Stop backtest if running
            running_backtest = False
            
            # Start live trading
            current_pair = request.form.get('pair', 'BTCUSDT')
            current_interval = request.form.get('interval', interval)
            
            if not running_live:
                running_live = True
                
                # Initialize client if needed
                initialize_client()
                
                # Start trading in a background thread
                trading_thread = Thread(target=run_live, args=(current_pair, current_interval))
                trading_thread.daemon = True
                trading_thread.start()
                
                add_bot_output(f"Started live trading for {current_pair}", context="live")
        
        elif action == 'stop':
            # Stop live trading
            running_live = False
            add_bot_output("Stopping live trading", context="live")
    
    return render_template('live.html', 
                                 usdt_pairs=pairs, 
                                 intervals=intervals, 
                                 current_pair=current_pair,
                                 current_interval=current_interval, 
                                 running_live=running_live,
                                 usdt_balance=balances.get('USDT', 0),
                                 usdc_balance=balances.get('USDC', 0),
                                 fdusd_balance=balances.get('FDUSD', 0),
                                 live_output=live_output)

@app.route('/backtest', methods=['GET', 'POST'])
def backtest():
    global running_backtest, running_live
    
    # Get pairs and set defaults
    pairs = get_usdt_pairs()
    current_pair = request.args.get('pair', 'BTCUSDT')
    current_interval = request.args.get('interval', interval)
    
    # Date handling
    today = datetime.now().strftime("%Y-%m-%d")
    start_date = request.args.get('start_date', (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"))
    end_date = request.args.get('end_date', today)
    
    # For chart display
    backtest_results = None
    chart_div = None
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'start':
            # Stop live trading if running
            running_live = False
            
            # Start backtest
            current_pair = request.form.get('pair', 'BTCUSDT')
            current_interval = request.form.get('interval', interval)
            start_date = request.form.get('start_date', start_date)
            end_date = request.form.get('end_date', end_date)
            
            # Clear previous backtest logs
            backtest_output.clear()
            
            if not running_backtest:
                running_backtest = True
                
                # Initialize client if needed
                initialize_client()
                
                add_bot_output(f"Started backtest for {current_pair} from {start_date} to {end_date}", context="backtest")
                
                # Run backtest synchronously to get results
                backtest_results = run_backtest(current_pair, current_interval, start_date, end_date)
                
                if backtest_results:
                    chart_div = backtest_results.get('chart_div')
                    add_bot_output(f"Backtest completed with profit: {backtest_results.get('total_profit')}", context="backtest")
                else:
                    add_bot_output("Failed to generate backtest results", context="backtest")
                
                running_backtest = False
        
        elif action == 'stop':
            # Stop backtest
            running_backtest = False
            add_bot_output("Stopping backtest", context="backtest")
    
    return render_template('backtest.html', 
                                 usdt_pairs=pairs, 
                                 intervals=intervals, 
                                 current_pair=current_pair,
                                 current_interval=current_interval,
                                 start_date=start_date,
                                 end_date=end_date, 
                                 today_date=today,
                                 running_backtest=running_backtest,
                                 current_total_money=current_total_money,
                                 backtest_output=backtest_output,
                                 backtest_results=backtest_results,
                                 chart_div=chart_div)

@app.route('/recommend', methods=['GET', 'POST'])
def recommend():
    recommended_coins = []
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'recommend':
            # Initialize client if needed
            initialize_client()
            
            # Find recommended coins
            recommended_coins = run_recommend()
    
    return render_template('recommend.html', 
                                 recommended_coins=recommended_coins,
                                 recommend_output=recommend_output)

@app.route('/api', methods=['GET', 'POST'])
def api():
    global api_key, api_secret, client
    
    if request.method == 'POST':
        api_key = request.form.get('api_key', '')
        api_secret = request.form.get('api_secret', '')
        
        # Initialize client with new API keys
        if api_key and api_secret:
            initialize_client()
    
    return render_template('api.html', 
                                 api_key=api_key, 
                                 api_secret=api_secret, 
                                 general_output=general_output)

@app.route('/variables', methods=['GET', 'POST'])
def variables():
    global rsi_length, oversold_level, overbought_level, proximity_range_percent, profit_range
    global max_buy_steps, interval, ema_period, trailing_start_rsi, trailing_stop_enabled
    global rsi_threshold, price_change_threshold, volume_change_threshold, volatility_threshold
    
    unlocked = False
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'unlock':
            password = request.form.get('password')
            if password == vars_password:
                unlocked = True
            else:
                add_bot_output("Invalid password for variables", context="api")
        
        elif action == 'save':
            # Update variables
            rsi_length = int(request.form.get('rsi_length', rsi_length))
            oversold_level = int(request.form.get('oversold_level', oversold_level))
            overbought_level = int(request.form.get('overbought_level', overbought_level))
            proximity_range_percent = float(request.form.get('proximity_range_percent', proximity_range_percent))
            profit_range = float(request.form.get('profit_range', profit_range))
            max_buy_steps = int(request.form.get('max_buy_steps', max_buy_steps))
            interval = request.form.get('interval', interval)
            ema_period = int(request.form.get('ema_period', ema_period))
            trailing_start_rsi = int(request.form.get('trailing_start_rsi', trailing_start_rsi))
            trailing_stop_enabled = request.form.get('trailing_stop_enabled', '0') == '1'
            rsi_threshold = int(request.form.get('rsi_threshold', rsi_threshold))
            price_change_threshold = float(request.form.get('price_change_threshold', price_change_threshold))
            volume_change_threshold = float(request.form.get('volume_change_threshold', volume_change_threshold))
            volatility_threshold = float(request.form.get('volatility_threshold', volatility_threshold))
            
            add_bot_output("Strategy variables updated", context="api")
            unlocked = True
    
    return render_template('variables.html', 
                                 unlocked=unlocked,
                                 rsi_length=rsi_length,
                                 oversold_level=oversold_level,
                                 overbought_level=overbought_level,
                                 proximity_range_percent=proximity_range_percent,
                                 profit_range=profit_range,
                                 max_buy_steps=max_buy_steps,
                                 intervals=intervals,
                                 interval=interval,
                                 ema_period=ema_period,
                                 trailing_start_rsi=trailing_start_rsi,
                                 trailing_stop_enabled=trailing_stop_enabled,
                                 rsi_threshold=rsi_threshold,
                                 price_change_threshold=price_change_threshold,
                                 volume_change_threshold=volume_change_threshold,
                                 volatility_threshold=volatility_threshold,
                                 general_output=general_output)

# Mobile API endpoints
@app.route('/api/ping', methods=['GET'])
def api_ping():
    """Simple endpoint to check if the API is running"""
    return jsonify({"status": "ok", "message": "ShahMate API is running"})

@app.route('/api/pairs', methods=['GET'])
def api_pairs():
    """Get all available trading pairs"""
    pairs = get_usdt_pairs()
    return jsonify({"pairs": pairs})

@app.route('/api/start_live', methods=['POST'])
def api_start_live():
    """Start live trading with parameters from the mobile app"""
    global active_symbol, active_interval, live_thread_running
    global rsi_length, oversold_level, overbought_level, ema_period, trailing_stop_enabled
    
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    # Extract parameters
    symbol = data.get('symbol', 'BTCUSDT')
    interval = data.get('interval', '1h')
    
    # Update strategy parameters if provided
    if 'length' in data:
        rsi_length = int(data.get('length'))
    if 'oversold_level' in data:
        oversold_level = int(data.get('oversold_level'))
    if 'overbought_level' in data:
        overbought_level = int(data.get('overbought_level'))
    if 'ema_period' in data:
        ema_period = int(data.get('ema_period'))
    if 'trailing_stop_enabled' in data:
        trailing_stop_enabled = bool(data.get('trailing_stop_enabled'))
    
    # Store in global variables
    active_symbol = symbol
    active_interval = interval
    
    add_bot_output(f"Starting live trading for {symbol} ({interval}) from mobile app", context="live")
    
    # Start live monitoring thread if not already running
    if not live_thread_running:
        threading.Thread(target=run_live, args=(symbol, interval), daemon=True).start()
    
    return jsonify({"status": "started", "symbol": symbol, "interval": interval})

@app.route('/api/stop_live', methods=['POST'])
def api_stop_live():
    """Stop live trading"""
    global live_thread_running
    
    add_bot_output("Stopping live trading from mobile app", context="live")
    live_thread_running = False
    return jsonify({"status": "stopped"})

@app.route('/api/backtest', methods=['POST'])
def api_backtest():
    """Run a backtest with parameters from the mobile app"""
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    # Extract parameters
    symbol = data.get('symbol', 'BTCUSDT')
    interval = data.get('interval', '1h')
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    initial_balance = float(data.get('initial_balance', 10000))
    
    add_bot_output(f"Running backtest for {symbol} ({interval}) from mobile app", context="backtest")
    
    # Run backtest
    try:
        results = run_backtest(symbol, interval, start_date, end_date)
        
        # Format results for API
        return jsonify({
            "symbol": symbol,
            "interval": interval,
            "start_date": start_date,
            "end_date": end_date,
            "initial_balance": initial_balance,
            "final_balance": results.get('final_balance', 0),
            "profit_percentage": results.get('profit_percentage', 0),
            "num_trades": results.get('num_trades', 0),
            "win_rate": results.get('win_rate', 0)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/log/<context>', methods=['GET'])
def api_logs(context):
    """Get logs for a specific context"""
    if context == 'live':
        logs = live_logs
    elif context == 'backtest':
        logs = backtest_logs
    elif context == 'recommend':
        logs = recommend_logs
    elif context == 'api':
        logs = api_logs
    else:
        logs = []
    
    return jsonify({"logs": logs})

@app.route('/api/set_keys', methods=['POST'])
def api_set_keys():
    """Set API keys from the mobile app"""
    global api_key, api_secret
    
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    new_api_key = data.get('api_key')
    new_api_secret = data.get('api_secret')
    
    if not new_api_key or not new_api_secret:
        return jsonify({"error": "API key and secret are required"}), 400
    
    # Update global variables
    api_key = new_api_key
    api_secret = new_api_secret
    
    add_bot_output("Updating API keys from mobile app", context="api")
    
    # Re-initialize the client with the new keys
    success = initialize_client()
    
    if success:
        return jsonify({"status": "API keys updated successfully"})
    else:
        return jsonify({"error": "Failed to connect with the provided API keys"}), 400

if __name__ == '__main__':
    # Create static files
    create_static_files()
    
    # Initial bot message
    add_bot_output("ShahMate Trading Bot started", context="info")
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=False)
# ShahMate Trading Bot - Termux Kurulum Talimatları

Bu paket, ShahMate Trading Bot'u Android telefonunuzda Termux uygulaması aracılığıyla doğrudan çalıştırmanızı sağlar. Bu şekilde IP kısıtlamalarından etkilenmeden 7/24 çalışabilir.

## Kurulum Adımları

### 1. Termux Uygulamasını İndirin

Google Play Store'dan [Termux](https://play.google.com/store/apps/details?id=com.termux) uygulamasını indirin ve yükleyin.

### 2. Dosyaları Telefonunuza Aktarın

1. Bu zip dosyasını telefonunuza indirin
2. Zip dosyasını açın ve içindeki dosyaları çıkarın

### 3. Termux'ta Kurulum

1. Termux'u açın
2. İlk olarak depolama alanına erişim izni verin:
   ```
   termux-setup-storage
   ```

3. Dosyaları Termux klasörüne kopyalayın (yollar telefonunuza göre değişebilir):
   ```
   cp -r /storage/emulated/0/Download/ShahMate/* ~
   ```

4. Kurulum scriptini çalıştırabilir yapın:
   ```
   chmod +x termux_run.sh
   ```

5. Kurulum scriptini çalıştırın:
   ```
   ./termux_run.sh
   ```

### 4. Arka Planda Çalıştırma

Uygulama Termux'u kapattığınızda da çalışmaya devam etsin istiyorsanız:

```
nohup python run.py &
```

Bu komut, uygulamayı arka planda çalıştıracak ve Termux'u kapatsanız bile çalışmaya devam edecektir.

### 5. Uygulamaya Erişim

1. Bot başarıyla çalıştığında, tarayıcınızdan şu adrese giderek kullanıcı arayüzüne erişebilirsiniz:
   ```
   http://localhost:5000
   ```

2. Eğer telefonunuzdaki diğer uygulamalardan erişmek istiyorsanız, `app.py` dosyasındaki IP adresini şu şekilde değiştirin:
   ```python
   app.run(host='0.0.0.0', port=5000)
   ```

   Bu şekilde telefonunuzdaki diğer uygulamalar `http://127.0.0.1:5000` adresinden bota erişebilir.

## Sorun Giderme

- **ModuleNotFoundError: No module named 'X'**: Eksik modülü yükleyin: `pip install X`
- **Permission denied**: Dosya izinlerini düzeltin: `chmod +x termux_run.sh`
- **Bağlantı hatası**: `app.py`'deki host parametresini `'0.0.0.0'` olarak değiştirin
- **Termux kapanınca bot duruyorsa**: `nohup` komutunu kullanarak arka planda çalıştırın

## Otomatik Başlatma

Telefonunuz yeniden başladığında botun otomatik başlaması için, Termux:Boot eklentisini yükleyebilirsiniz. Google Play'den bu eklentiyi yükledikten sonra:

1. Termux:Boot uygulamasını açın ve gerekli izinleri verin
2. Termux'ta şu komutu çalıştırın:
   ```
   mkdir -p ~/.termux/boot
   ```

3. Başlatma dosyası oluşturun:
   ```
   echo "#!/data/data/com.termux/files/usr/bin/sh" > ~/.termux/boot/start-shahmate
   echo "cd ~/ShahMate" >> ~/.termux/boot/start-shahmate
   echo "nohup python run.py &" >> ~/.termux/boot/start-shahmate
   chmod +x ~/.termux/boot/start-shahmate
   ```

Bu şekilde, telefonunuz her yeniden başladığında ShahMate Trading Bot otomatik olarak başlayacaktır.
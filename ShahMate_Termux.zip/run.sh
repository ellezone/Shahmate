#!/bin/bash
# ShahMate Trading Bot - Termux Setup Script

# Update packages
echo "Updating Termux packages..."
pkg update -y
pkg upgrade -y

# Install required packages
echo "Installing required packages..."
pkg install python -y
pkg install git -y

# Create virtual environment (optional but recommended)
echo "Setting up Python environment..."
pip install --upgrade pip
pip install -r termux_requirements.txt

# Set up environment
echo "Setting up environment..."
mkdir -p static
mkdir -p templates
touch .env

# Start the application
echo "Starting ShahMate Trading Bot..."
python run.py

# Instructions to run in background
echo ""
echo "-------------------------------------------"
echo "To run in background after closing Termux:"
echo "nohup python run.py &"
echo ""
echo "To check if it's running:"
echo "ps aux | grep python"
echo "-------------------------------------------"
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import pytz
import requests

# Helper functions for strategy
def convert_to_tr_time(utc_timestamp):
    """Convert UTC timestamp to Turkish time"""
    try:
        utc_time = datetime.fromtimestamp(utc_timestamp / 1000, tz=pytz.UTC)
        tr_timezone = pytz.timezone('Europe/Istanbul')
        tr_time = utc_time.astimezone(tr_timezone)
        return tr_time.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def calculate_rsi(data, period):
    """Calculate RSI using pandas for better accuracy"""
    if isinstance(data, list):
        data = pd.Series(data)
    
    if len(data) < period + 1:
        return 0
        
    delta = data.diff(1).dropna()
    if len(delta) < period:
        return 0
    
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    
    avg_gain = pd.Series(gain).rolling(window=period, min_periods=period).mean().iloc[-1]
    avg_loss = pd.Series(loss).rolling(window=period, min_periods=period).mean().iloc[-1]
    
    if avg_loss == 0:
        return 100 if avg_gain > 0 else 50
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi if not np.isnan(rsi) else 50

def calculate_ema(series, period):
    """Calculate EMA using pandas for better accuracy"""
    if isinstance(series, list):
        series = pd.Series(series)
        
    return series.ewm(span=period, adjust=False).mean()

def is_above_ema(closes, period):
    """Check if current price is above EMA"""
    if isinstance(closes, list):
        closes = pd.Series(closes)
        
    if len(closes) < period:
        return False
        
    ema = calculate_ema(closes, period).iloc[-1]
    return closes.iloc[-1] > ema

def crossover(series, level):
    """Detect when value crosses above a level"""
    if isinstance(series, list):
        series = pd.Series(series)
        
    if len(series) < 2:
        return False
        
    return series.iloc[-2] <= level and series.iloc[-1] > level

def crossunder(series, level):
    """Detect when value crosses below a level"""
    if isinstance(series, list):
        series = pd.Series(series)
        
    if len(series) < 2:
        return False
        
    return series.iloc[-2] >= level and series.iloc[-1] < level

def get_historical_klines(symbol, interval, limit=1000, total_limit=30000, start_time=None, end_time=None, client=None, log_callback=None):
    """Get historical klines data with multiple fallback options"""
    all_data = []
    
    # First try: Use client if available
    if client:
        try:
            klines = client.get_historical_klines(
                symbol=symbol, 
                interval=interval, 
                limit=limit,
                start_str=start_time,
                end_str=end_time
            )
            
            if klines and len(klines) > 0:
                if log_callback:
                    log_callback(f"Retrieved {len(klines)} candles from Binance API")
                return klines
        except Exception as e:
            if log_callback:
                log_callback(f"Error using client API: {str(e)}")
            # Fall through to public API
    
    # Second try: Public API
    if start_time is None or end_time is None:
        end_time = int(time.time() * 1000)
        start_time = end_time - (24 * 60 * 60 * 1000)
    
    current_start_time = start_time
    
    try:
        while current_start_time < end_time and len(all_data) < total_limit:
            url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}&startTime={current_start_time}&endTime={end_time}"
            
            response = requests.get(url, timeout=10)
            if response.status_code != 200 or not response.json():
                break
                
            data = response.json()
            all_data.extend(data)
            
            if len(data) < limit:
                break
                
            current_start_time = int(data[-1][0]) + 1000
            time.sleep(0.1)  # Be nice to the API
    except Exception as e:
        if log_callback:
            log_callback(f"Failed to get klines from public API: {str(e)}")
    
    if all_data:
        if log_callback:
            log_callback(f"Retrieved {len(all_data)} candles from public API")
        return all_data
    
    # Final fallback: If no real data, generate simulated data
    if log_callback:
        log_callback("Using simulated data for backtest")
        
    return generate_simulated_klines(symbol, interval, limit, start_time, end_time)

def generate_simulated_klines(symbol, interval, limit=1000, start_time=None, end_time=None):
    """Generate simulated price data for testing"""
    import random
    
    # Base volatility factors based on common crypto assets
    volatility_factors = {
        "BTCUSDT": 0.025,   # BTC is less volatile
        "ETHUSDT": 0.035,   # ETH is moderately volatile
        "BNBUSDT": 0.04,    # BNB is moderately volatile
        "SOLUSDT": 0.055,   # SOL is more volatile
        "DOGEUSDT": 0.08,   # DOGE is highly volatile
        "XRPUSDT": 0.05,    # XRP is moderately volatile
    }
    
    # Default volatility if specific symbol not found
    volatility = volatility_factors.get(symbol, 0.045)  # 4.5% average volatility
    
    # Set reasonable base price based on symbol
    if "BTC" in symbol:
        base_price = 45000 + (random.random() * 10000)
    elif "ETH" in symbol:
        base_price = 2500 + (random.random() * 1000)
    elif "BNB" in symbol:
        base_price = 350 + (random.random() * 50)
    elif "SOL" in symbol:
        base_price = 120 + (random.random() * 20)
    elif "DOGE" in symbol:
        base_price = 0.1 + (random.random() * 0.05)
    elif "XRP" in symbol:
        base_price = 0.5 + (random.random() * 0.2)
    else:
        # For other coins, generate a reasonable random price
        magnitude = random.choice([0.1, 1, 10, 100])
        base_price = magnitude * (1 + random.random())
    
    # Determine the candle duration in seconds based on interval
    seconds_map = {
        "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
        "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "8h": 28800,
        "12h": 43200, "1d": 86400, "3d": 259200, "1w": 604800
    }
    candle_seconds = seconds_map.get(interval, 3600)  # Default to 1h
    
    # Set proper time range
    if not end_time:
        end_time = int(time.time() * 1000)  # Current time in milliseconds
    if not start_time:
        # Calculate start time based on limit and interval
        start_time = end_time - (candle_seconds * 1000 * limit)
    
    # Initialize simulated data points
    klines = []
    current_price = base_price
    current_time = start_time
    
    # Generate data points
    for i in range(limit):
        # Random price movement with volatility factor
        price_change_pct = random.normalvariate(0, volatility)
        price_change = current_price * price_change_pct
        
        # Calculate prices
        open_price = current_price
        close_price = current_price + price_change
        high_price = max(open_price, close_price) * (1 + abs(random.normalvariate(0, volatility/2)))
        low_price = min(open_price, close_price) * (1 - abs(random.normalvariate(0, volatility/2)))
        
        # Generate volume (larger when price changes more)
        base_volume = abs(price_change) * 1000 * (1 + random.random())
        volume = max(base_volume, 100)  # Ensure some minimum volume
        
        # Create kline data in Binance format
        kline = [
            current_time,                           # Open time
            f"{open_price:.8f}",                    # Open
            f"{high_price:.8f}",                    # High
            f"{low_price:.8f}",                     # Low
            f"{close_price:.8f}",                   # Close
            f"{volume:.8f}",                        # Volume
            current_time + (candle_seconds * 1000), # Close time
            f"{volume * open_price:.8f}",           # Quote asset volume
            100,                                    # Number of trades
            f"{volume * 0.4:.8f}",                  # Taker buy base asset volume
            f"{volume * 0.4 * open_price:.8f}",     # Taker buy quote asset volume
            "0"                                     # Ignore
        ]
        
        klines.append(kline)
        
        # Update for next iteration
        current_price = close_price
        current_time += candle_seconds * 1000
    
    return klines

# Main backtest function using pandas-based calculations
def run_backtest(symbol, interval, initial_balance, length, oversold_level, overbought_level, 
                 proximity_range_percent, profit_range, max_buy_steps, ema_period, 
                 trailing_start_rsi, trailing_stop_enabled, start_date=None, end_date=None, 
                 client=None, log_callback=None):
    """Run a backtest with the given parameters using pandas calculations"""
    try:
        # Reset variables for this backtest
        current_total_money = initial_balance
        total_spent = 0
        total_coins = 0
        total_profit_accumulated = 0
        buy_counter = 0
        last_buy_price = None
        base_amount = current_total_money / max_buy_steps
        avg_price = 0
        trailing_active = False
        trailing_peak_rsi = 0
        trailing_peak_value = 0

        # Convert dates to timestamps
        if start_date and end_date:
            start_time = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp() * 1000)
            end_time = int(datetime.strptime(end_date, '%Y-%m-%d').timestamp() * 1000)
        else:
            end_time = int(time.time() * 1000)
            start_time = end_time - (30 * 24 * 60 * 60 * 1000)  # 30 days by default

        # Get historical data
        klines = get_historical_klines(symbol, interval, start_time=start_time, end_time=end_time, 
                                      client=client, log_callback=log_callback)
        
        if not klines or len(klines) < length + 1:
            if log_callback:
                log_callback("❌ Not enough data for backtest!")
            return None, None, None, None
            
        # Convert klines to DataFrame
        df = pd.DataFrame(klines, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 
                                           'quote_asset_volume', 'num_trades', 'taker_base_vol', 
                                           'taker_quote_vol', 'ignore'])
        
        # Convert numeric columns
        df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(float)
        
        # Convert timestamps to readable format
        df['timestamp'] = df['timestamp'].apply(lambda x: convert_to_tr_time(int(x)))
        
        # Extract data for strategy
        times = df['timestamp']
        closes = df['close']
        
        # Calculate RSI series for each candle
        rsi_series = pd.Series([calculate_rsi(closes[:i+1], length) for i in range(len(closes))])
        
        # Calculate EMA
        ema_values = calculate_ema(closes, ema_period)
        
        # For tracking points on chart
        buy_points = []
        sell_points = []
        
        # Process each candle for backtest
        for i in range(length + 1, len(closes)):
            close = closes.iloc[i]
            time_str = times.iloc[i]
            rsi = rsi_series.iloc[i]
            
            # Check for crossover buy signal
            buy_signal = crossover(rsi_series.iloc[i-2:i+1], oversold_level)
            proximity_condition = last_buy_price is None or close < last_buy_price * (1 - proximity_range_percent / 100)
            above_ema = is_above_ema(closes.iloc[:i+1], ema_period)

            if buy_signal and buy_counter < max_buy_steps and proximity_condition and above_ema and current_total_money > base_amount:
                buy_counter += 1
                last_buy_price = float(close)
                buy_amount = base_amount
                quantity = buy_amount / float(close)
                total_coins += quantity
                total_spent += buy_amount
                current_total_money -= buy_amount
                avg_price = total_spent / total_coins
                
                buy_points.append((time_str, close))
                
                if log_callback:
                    log_callback(f"[{time_str}] ✅ BUY #{buy_counter}: {quantity:.4f} {symbol[:-4]} | Price: {close:.4f} | RSI: {rsi:.2f}")

            # Sell-side logic
            if total_coins > 0:
                total_current_value = float(close) * total_coins
                profit_threshold = total_spent * (1 + profit_range / 100)
                rsi_exit = crossunder(rsi_series.iloc[i-2:i+1], overbought_level)
                profit_positive = total_current_value >= profit_threshold and total_coins > 0

                # Trailing stop logic
                if total_coins > 0 and rsi >= trailing_start_rsi and profit_positive and trailing_stop_enabled:
                    if not trailing_active:
                        trailing_active = True
                        trailing_peak_rsi = rsi
                        trailing_peak_value = total_current_value
                        if log_callback:
                            log_callback(f"[{time_str}] 📈 Trailing Stop activated | RSI: {rsi:.2f}")
                    elif rsi > trailing_peak_rsi + 5:
                        trailing_peak_rsi = rsi
                        trailing_peak_value = total_current_value
                        if log_callback:
                            log_callback(f"[{time_str}] 📈 Trailing Stop updated | RSI: {rsi:.2f}")

                # Handle sell signals
                if total_coins > 0 and profit_positive:
                    sell_triggered = False
                    
                    # Trailing stop sell
                    if trailing_stop_enabled and trailing_active and rsi < trailing_peak_rsi - 5:
                        profit = total_current_value - total_spent
                        total_profit_accumulated += profit
                        current_total_money += total_current_value
                        
                        sell_points.append((time_str, close))
                        
                        if log_callback:
                            log_callback(f"[{time_str}] ✅ SELL (Trailing): Profit: {profit:.2f} USDT | RSI: {rsi:.2f}")
                        
                        total_coins = 0
                        total_spent = 0
                        buy_counter = 0
                        last_buy_price = None
                        avg_price = 0
                        trailing_active = False
                        trailing_peak_rsi = 0
                        trailing_peak_value = 0
                        sell_triggered = True
                    
                    # RSI overbought sell
                    elif rsi_exit and not sell_triggered:
                        profit = total_current_value - total_spent
                        total_profit_accumulated += profit
                        current_total_money += total_current_value
                        
                        sell_points.append((time_str, close))
                        
                        if log_callback:
                            log_callback(f"[{time_str}] ✅ SELL: Profit: {profit:.2f} USDT | RSI: {rsi:.2f}")
                        
                        total_coins = 0
                        total_spent = 0
                        buy_counter = 0
                        last_buy_price = None
                        avg_price = 0
                        trailing_active = False
                        trailing_peak_rsi = 0
                        trailing_peak_value = 0

        # Calculate final metrics
        roi_percent = ((current_total_money / initial_balance) - 1) * 100
        
        if log_callback:
            log_callback(f"📊 Backtest completed | Total Profit: {total_profit_accumulated:.2f} USDT | ROI: {roi_percent:.2f}%")
        
        return times, closes, rsi_series, ema_values, buy_points, sell_points, current_total_money, total_profit_accumulated, roi_percent
    
    except Exception as e:
        if log_callback:
            log_callback(f"❌ Backtest error: {str(e)}")
        return None, None, None, None, None, None, None, None, None

# Live trading function
def run_live_trading(symbol, interval, length, oversold_level, overbought_level, 
                    proximity_range_percent, profit_range, max_buy_steps, ema_period, 
                    trailing_start_rsi, trailing_stop_enabled, client=None, log_callback=None,
                    place_buy_order=None, place_sell_order=None, get_balances=None):
    """Run live trading with the given parameters"""
    try:
        # Get balances
        balances = get_balances() if get_balances else {"USDT": 15000, "USDC": 5000, "FDUSD": 0}
        current_total_money = balances.get("USDT", 0)
        
        if current_total_money <= 0:
            if log_callback:
                log_callback("❌ No USDT balance available!")
            return None, None
        
        # Get live data
        klines = get_historical_klines(symbol, interval, limit=100, client=client, log_callback=log_callback)
        
        if not klines or len(klines) < length + 1:
            if log_callback:
                log_callback("❌ Not enough data for analysis!")
            return None, None
            
        # Convert klines to DataFrame
        df = pd.DataFrame(klines, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 
                                          'quote_asset_volume', 'num_trades', 'taker_base_vol', 
                                          'taker_quote_vol', 'ignore'])
        
        # Convert numeric columns
        df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(float)
        
        # Convert timestamps to readable format
        df['timestamp'] = df['timestamp'].apply(lambda x: convert_to_tr_time(int(x)))
        
        # Extract data for strategy
        time_str = df['timestamp'].iloc[-1]
        closes = df['close']
        current_price = closes.iloc[-1]
        
        # Calculate RSI series
        rsi_series = pd.Series([calculate_rsi(closes[:i+1], length) for i in range(len(closes))])
        current_rsi = rsi_series.iloc[-1]
        
        # Calculate EMA
        ema_values = calculate_ema(closes, ema_period)
        above_ema = current_price > ema_values.iloc[-1]
        
        # State for displaying to user
        state = {
            'symbol': symbol,
            'time': time_str,
            'price': current_price,
            'rsi': current_rsi,
            'above_ema': above_ema,
            'balances': balances
        }
        
        if log_callback:
            log_callback(f"[{time_str}] {symbol} Price: {current_price:.4f} | RSI: {current_rsi:.2f} | Above EMA: {above_ema}")
        
        # Check for buy signal - we're just analyzing, not executing here
        buy_signal = crossover(rsi_series.iloc[-3:], oversold_level)
        
        if buy_signal and above_ema:
            if log_callback:
                log_callback(f"[{time_str}] 🔍 BUY SIGNAL DETECTED for {symbol}! RSI: {current_rsi:.2f}")
        
        # Check for sell signal
        sell_signal = crossunder(rsi_series.iloc[-3:], overbought_level)
        
        if sell_signal:
            if log_callback:
                log_callback(f"[{time_str}] 🔍 SELL SIGNAL DETECTED for {symbol}! RSI: {current_rsi:.2f}")
        
        return state, df
    
    except Exception as e:
        if log_callback:
            log_callback(f"❌ Error in live analysis: {str(e)}")
        return None, None
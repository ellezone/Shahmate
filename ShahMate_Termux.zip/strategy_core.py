import pandas as pd
import numpy as np
from datetime import datetime
import pytz
import requests
import time

# Strategy helper functions
def convert_to_tr_time(utc_timestamp):
    """Convert UTC timestamp to Turkish time"""
    try:
        utc_time = datetime.fromtimestamp(utc_timestamp / 1000, tz=pytz.UTC)
        tr_timezone = pytz.timezone('Europe/Istanbul')
        tr_time = utc_time.astimezone(tr_timezone)
        return tr_time.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def calculate_rsi(data, period):
    """Calculate RSI using pandas for better accuracy"""
    if len(data) < period + 1:
        return 0
    
    # Convert to pandas Series if it's not already
    if not isinstance(data, pd.Series):
        data = pd.Series(data)
        
    delta = data.diff(1).dropna()
    if len(delta) < period:
        return 0
    
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    
    avg_gain = pd.Series(gain).rolling(window=period, min_periods=period).mean().iloc[-1]
    avg_loss = pd.Series(loss).rolling(window=period, min_periods=period).mean().iloc[-1]
    
    if avg_loss == 0:
        return 100 if avg_gain > 0 else 50
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi if not np.isnan(rsi) else 50

def calculate_ema(series, period):
    """Calculate EMA using pandas for better accuracy"""
    # Convert to pandas Series if it's not already
    if not isinstance(series, pd.Series):
        series = pd.Series(series)
        
    return series.ewm(span=period, adjust=False).mean()

def is_above_ema(closes, period):
    """Check if current price is above EMA"""
    if len(closes) < period:
        return False
    
    # Convert to pandas Series if it's not already
    if not isinstance(closes, pd.Series):
        closes = pd.Series(closes)
        
    ema = calculate_ema(closes, period).iloc[-1]
    return closes.iloc[-1] > ema

def crossover(series, level):
    """Detect when value crosses above a level"""
    if len(series) < 2:
        return False
    
    # Convert to pandas Series if it's not already
    if not isinstance(series, pd.Series):
        series = pd.Series(series)
        
    return series.iloc[-2] <= level and series.iloc[-1] > level

def crossunder(series, level):
    """Detect when value crosses below a level"""
    if len(series) < 2:
        return False
    
    # Convert to pandas Series if it's not already
    if not isinstance(series, pd.Series):
        series = pd.Series(series)
        
    return series.iloc[-2] >= level and series.iloc[-1] < level

def get_historical_data(symbol, interval, limit=1000, start_time=None, end_time=None, client=None, add_log_callback=None):
    """Get historical price data and convert to pandas DataFrame"""
    all_data = []
    
    # If client is available, try using it first
    if client:
        try:
            if start_time and end_time:
                klines = client.get_historical_klines(
                    symbol=symbol, 
                    interval=interval, 
                    limit=limit,
                    start_str=start_time,
                    end_str=end_time
                )
            else:
                klines = client.get_klines(symbol=symbol, interval=interval, limit=limit)
                
            if klines and len(klines) > 0:
                if add_log_callback:
                    add_log_callback(f"Retrieved {len(klines)} candles from Binance API")
                all_data = klines
        except Exception as e:
            if add_log_callback:
                add_log_callback(f"Error using client API: {str(e)}")
            # Fall through to public API
    
    # If no data or no client, try public API
    if not all_data:
        base_url = "https://api.binance.com"
        if start_time is None or end_time is None:
            end_time = int(time.time() * 1000)
            start_time = end_time - (24 * 60 * 60 * 1000)
            
        current_start_time = start_time
        
        while current_start_time < end_time:
            url = f"{base_url}/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}&startTime={current_start_time}&endTime={end_time}"
            try:
                response = requests.get(url, timeout=10)
                if response.status_code != 200 or not response.json():
                    break
                data = response.json()
                all_data.extend(data)
                if len(data) < limit:
                    break
                current_start_time = int(data[-1][0]) + 1000
                time.sleep(0.1)
            except Exception as e:
                if add_log_callback:
                    add_log_callback(f"Error getting klines from API: {str(e)}")
                break
    
    # Process data if we have any
    if all_data:
        df = pd.DataFrame(all_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 
                                            'close_time', 'quote_asset_volume', 'num_trades', 
                                            'taker_base_vol', 'taker_quote_vol', 'ignore'])
        
        # Convert timestamp to readable format
        df['timestamp'] = df['timestamp'].apply(lambda x: convert_to_tr_time(int(x)))
        
        # Convert price columns to float
        df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(float)
        
        return df
    
    return None

def apply_strategy(df, length, oversold_level, overbought_level, ema_period, add_log_callback=None):
    """Apply the RSI strategy to historical data and identify buy/sell points"""
    if df is None or len(df) < length + 1:
        if add_log_callback:
            add_log_callback("Not enough data for strategy calculation")
        return None, None, None
    
    # Calculate RSI
    rsi_values = []
    
    # Create a copy of the close price series
    closes = df['close'].copy()
    
    # Use cumulative calculations for each point
    for i in range(1, len(closes) + 1):
        subset = closes.iloc[:i]
        rsi = calculate_rsi(subset, length)
        rsi_values.append(rsi)
    
    rsi_series = pd.Series(rsi_values)
    
    # Calculate EMA
    ema_values = calculate_ema(closes, ema_period)
    
    # Find buy and sell signals
    buy_points = []
    sell_points = []
    
    for i in range(length + 1, len(closes)):
        # Check for buy signal
        if crossover(rsi_series.iloc[i-2:i+1], oversold_level) and closes.iloc[i] > ema_values.iloc[i]:
            buy_points.append((df['timestamp'].iloc[i], closes.iloc[i]))
        
        # Check for sell signal
        if crossunder(rsi_series.iloc[i-2:i+1], overbought_level):
            sell_points.append((df['timestamp'].iloc[i], closes.iloc[i]))
    
    return rsi_series, ema_values, buy_points, sell_points

def run_backtest(
    symbol, interval, start_date, end_date, initial_balance, 
    length, oversold_level, overbought_level, proximity_range_percent, 
    profit_range, max_buy_steps, ema_period, trailing_start_rsi,
    trailing_stop_enabled, client=None, add_log_callback=None
):
    """Run a backtest using pandas-based calculations"""
    try:
        # Initialize variables
        current_total_money = initial_balance
        total_spent = 0
        total_coins = 0
        total_profit_accumulated = 0
        buy_counter = 0
        last_buy_price = None
        base_amount = current_total_money / max_buy_steps
        avg_price = 0
        trailing_active = False
        trailing_peak_rsi = 0
        trailing_peak_value = 0
        buy_points = []
        sell_points = []
        
        # Convert dates to timestamps
        start_time = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp() * 1000)
        end_time = int(datetime.strptime(end_date, '%Y-%m-%d').timestamp() * 1000)
        
        # Get historical data
        df = get_historical_data(symbol, interval, limit=1000, start_time=start_time, end_time=end_time, 
                                client=client, add_log_callback=add_log_callback)
        
        if df is None or len(df) < length + 1:
            if add_log_callback:
                add_log_callback("❌ Not enough data for backtest!")
            return None, None
        
        if add_log_callback:
            add_log_callback(f"Loaded {len(df)} candles for backtest")
        
        # Calculate indicators
        closes = df['close']
        times = df['timestamp']
        
        # Calculate RSI for each point
        rsi_series = pd.Series([calculate_rsi(closes.iloc[:i], length) for i in range(1, len(closes) + 1)])
        
        # Process each candle
        for i in range(length + 1, len(closes)):
            close = closes.iloc[i]
            time_str = times.iloc[i]
            rsi = rsi_series.iloc[i]
            
            # Buy signal logic
            buy_signal = crossover(rsi_series.iloc[i-2:i+1], oversold_level)
            proximity_condition = last_buy_price is None or close < last_buy_price * (1 - proximity_range_percent / 100)
            above_ema = is_above_ema(closes.iloc[:i+1], ema_period)
            
            if buy_signal and buy_counter < max_buy_steps and proximity_condition and above_ema and current_total_money > base_amount:
                buy_counter += 1
                last_buy_price = float(close)
                buy_amount = base_amount
                quantity = buy_amount / float(close)
                total_coins += quantity
                total_spent += buy_amount
                current_total_money -= buy_amount
                avg_price = total_spent / total_coins
                
                buy_points.append((time_str, close))
                
                if add_log_callback:
                    add_log_callback(f"[{time_str}] ✅ BUY #{buy_counter}: {quantity:.4f} {symbol[:-4]} | Price: {close:.4f} | RSI: {rsi:.2f}")
            
            # Handle selling
            total_current_value = float(close) * total_coins
            profit_threshold = total_spent * (1 + profit_range / 100)
            rsi_exit = crossunder(rsi_series.iloc[i-2:i+1], overbought_level)
            profit_positive = total_current_value >= profit_threshold and total_coins > 0
            
            # Trailing stop logic
            if total_coins > 0 and rsi >= trailing_start_rsi and profit_positive and trailing_stop_enabled:
                if not trailing_active:
                    trailing_active = True
                    trailing_peak_rsi = rsi
                    trailing_peak_value = total_current_value
                    if add_log_callback:
                        add_log_callback(f"[{time_str}] 📈 Trailing Stop activated | RSI: {rsi:.2f}")
                elif rsi > trailing_peak_rsi + 5:
                    trailing_peak_rsi = rsi
                    trailing_peak_value = total_current_value
                    if add_log_callback:
                        add_log_callback(f"[{time_str}] 📈 Trailing Stop updated | RSI: {rsi:.2f}")
            
            # Handle sell signals
            if total_coins > 0 and profit_positive:
                sold = False
                
                # Trailing stop sell
                if trailing_stop_enabled and trailing_active and rsi < trailing_peak_rsi - 5:
                    profit = total_current_value - total_spent
                    total_profit_accumulated += profit
                    current_total_money += total_current_value
                    
                    sell_points.append((time_str, close))
                    
                    if add_log_callback:
                        add_log_callback(f"[{time_str}] ✅ SELL (Trailing): Profit: {profit:.2f} USDT | RSI: {rsi:.2f}")
                    
                    total_coins = 0
                    total_spent = 0
                    buy_counter = 0
                    last_buy_price = None
                    avg_price = 0
                    trailing_active = False
                    trailing_peak_rsi = 0
                    trailing_peak_value = 0
                    sold = True
                
                # RSI overbought sell
                elif rsi_exit and not sold:
                    profit = total_current_value - total_spent
                    total_profit_accumulated += profit
                    current_total_money += total_current_value
                    
                    sell_points.append((time_str, close))
                    
                    if add_log_callback:
                        add_log_callback(f"[{time_str}] ✅ SELL: Profit: {profit:.2f} USDT | RSI: {rsi:.2f}")
                    
                    total_coins = 0
                    total_spent = 0
                    buy_counter = 0
                    last_buy_price = None
                    avg_price = 0
                    trailing_active = False
                    trailing_peak_rsi = 0
                    trailing_peak_value = 0
        
        # Calculate final metrics
        roi_percent = ((current_total_money / initial_balance) - 1) * 100
        
        if add_log_callback:
            add_log_callback(f"📊 Backtest completed | Total Profit: {total_profit_accumulated:.2f} USDT | ROI: {roi_percent:.2f}%")
        
        return {
            'initial_balance': initial_balance,
            'final_balance': current_total_money,
            'total_profit': total_profit_accumulated,
            'roi': roi_percent,
            'buy_points': buy_points,
            'sell_points': sell_points
        }, df
    
    except Exception as e:
        if add_log_callback:
            add_log_callback(f"❌ Backtest error: {str(e)}")
        return None, None